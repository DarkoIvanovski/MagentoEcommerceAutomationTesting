package com.softwaretestingboard.magento.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class BugReport extends BaseTest {

    @Test
    public void bugNo1() {
        privacyPolicyPage.navigateToPrivacyPolicyPage();
        privacyPolicyPage.clickOnQuestionsForLuma();
        privacyPolicyPage.clickOnContactUs();
        Assert.assertEquals(privacyPolicyPage.getBugMessage(),"Whoops, our bad...");
    }
}
