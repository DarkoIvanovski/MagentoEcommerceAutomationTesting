package com.softwaretestingboard.magento.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class HomeTests extends BaseTest {

    @Test
    public void testMainFunctionalityInHomePage() throws InterruptedException {
        homePage.navigateToHomePage();
        homePage.clickOnSignIn();
        homePage.navigateToHomePage();
        homePage.clickOnCreateAnAccount();
        homePage.clickOnHomeLogoButton();
        homePage.typeInSearchField("tee");
        Assert.assertEquals(homePage.getSearchFieldResultsMessage(), "Search results for: 'tee'");
        homePage.clearDataInSearchField();
    }

    @Test
    public void navigateToProductsByImage() {
        homePage.navigateToHomePage();
        homePage.clickOnShopNewYoga();
        homePage.clickOnPantsOnDiscount();
        homePage.clickOnThreeLumaShirts();
        homePage.clickOnTakeFromErin();
        homePage.clickOnScienceMeetPerformance();
        homePage.clickOnShopEcoFriendly();
    }

    @Test
    public void openProductFromHomePage() {
        homePage.navigateToHomePage();
        homePage.clickOnRadiantTee();
        homePage.clickOnBreatheEasyTank();
        homePage.clickOnArgusAllWeatherTank();
        homePage.clickOnHeroHoodie();
    }

    @Test
    public void addProductToCart() throws InterruptedException {
        homePage.navigateToHomePage();
        homePage.clickAddToCartFusionBackpack();
        homePage.clickOnAddToCartPushItMessengerBag();
        Thread.sleep(2000);
        homePage.clickOnCartIcon();
        Assert.assertEquals(homePage.getItemsInCartMessage(), "2");
        Assert.assertEquals(homePage.getSubtotalPriceMessage(), "$104.00");
        Assert.assertEquals(homePage.getFirstProductInCart(), "Push It Messenger Bag");
        Assert.assertEquals(homePage.getFirstProductInCartPrice(), "$45.00");
        Assert.assertEquals(homePage.getSecondProductInCart(), "Fusion Backpack");
        Assert.assertEquals(homePage.getSecondProductInCartPrice(), "$59.00");
    }

    @Test
    public void deleteProductFromCart() throws InterruptedException {
        homePage.navigateToHomePage();
        homePage.clickAddToCartFusionBackpack();
        homePage.clickOnAddToCartPushItMessengerBag();
        Thread.sleep(2000);
        homePage.clickOnCartIcon();
        homePage.clickOnDeleteButton();
        homePage.clickOkOnDeleteMessage();
    }

    @Test
    public void testFooterLinks() throws InterruptedException {
        homePage.navigateToHomePage();
        homePage.clickOnSupportThisProject();
        homePage.clickOnNotesLink();
        homePage.clickOnPracticeAPITestingUsingMagentoLink();
        homePage.clickOnWriteForUsLink();
        homePage.clickOnSubscribeLink();
        homePage.clickOnSearchTermsLink();
        homePage.clickOnPrivacyAndCookieLink();
        homePage.clickOnAdvancedSearch();
        homePage.clickOnOrdersAndReturnsLink();
    }

    @Test
    public void clickOnRightBottomPopUpMessage() throws InterruptedException {
        homePage.navigateToHomePage();
        Thread.sleep(1500);
        homePage.clickOnRightBottomPopUpMessage();
        homePage.clickEscapeOnRightBottomPopUpMessage();
    }
}

