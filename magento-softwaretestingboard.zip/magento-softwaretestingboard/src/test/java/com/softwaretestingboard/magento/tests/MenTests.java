package com.softwaretestingboard.magento.tests;

import org.testng.annotations.Test;

public class MenTests extends BaseTest{

    @Test
    public void shopByCategory() {
        menPage.navigateToMenPage();
        menPage.clickOnTops();
        menPage.navigateToMenPage();
        menPage.clickOnBottoms();
        menPage.navigateToMenPage();
        menPage.clickOnHoodiesAndSweatshirt();
        menPage.navigateToMenPage();
        menPage.clickOnJackets();
        menPage.navigateToMenPage();
        menPage.clickOnTees();
        menPage.navigateToMenPage();
        menPage.clickOnTanks();
        menPage.navigateToMenPage();
        menPage.clickOnPants();
        menPage.navigateToMenPage();
        menPage.clickOnShorts();
        menPage.navigateToMenPage();
    }

    @Test
    public void shopByHeaderImages() throws InterruptedException {
        menPage.navigateToMenPage();
        menPage.clickOnShopPerformance();
        menPage.clickOnThreeShirts();
        menPage.clickOnDiscountPants();
        menPage.clickOnLumaShorts();
        menPage.clickOnLumaTees();
        menPage.clickOnLumaHoodies();
    }

    @Test
    public void hotSellersProducts() throws InterruptedException {
        menPage.navigateToMenPage();
        menPage.clickOnArgusAllWeatherTank();
        menPage.clickOnHeroHoodie();
        menPage.clickOnMeteorWorkoutShorts();
        menPage.clickOnGeoInsulatedJoggingPant();
    }
}
