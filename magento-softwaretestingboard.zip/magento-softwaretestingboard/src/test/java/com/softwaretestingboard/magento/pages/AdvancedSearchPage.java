package com.softwaretestingboard.magento.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AdvancedSearchPage {

    WebDriver driver;
    WebDriverWait wait;

    public AdvancedSearchPage(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    private String advancedSearchPageUrl = "https://magento.softwaretestingboard.com/catalogsearch/advanced/";

    private By productName = By.id("name");
    private By skuCode = By.id("sku");
    private By priceFrom = By.id("price");
    private By priceTo = By.id("price_to");
    private By searchButton = By.xpath("//button[@class='action search primary']");

    public void navigateToAdvancedSearchPage() {
        driver.navigate().to(advancedSearchPageUrl);
    }

    public void enterProductName (String product) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(productName)).sendKeys(product);
    }

    public void enterSkuCode (String sku) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(skuCode)).sendKeys(sku);
    }

    public void enterPriceFrom (String price1) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(priceFrom)).sendKeys(price1);
    }

    public void enterPriceTo (String price2) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(priceTo)).sendKeys(price2);
    }

    public void clickOnSearchButton() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(searchButton)).click();
    }


}
