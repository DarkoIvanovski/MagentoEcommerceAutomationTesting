package com.softwaretestingboard.magento.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class AddProductToWishlistPage {

    WebDriver driver;
    WebDriverWait wait;

    public AddProductToWishlistPage(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    private String myWishListPageUrl = "https://magento.softwaretestingboard.com/wishlist/";

    private By arcadioGymShorts =By.xpath("//a[contains(text(),'Arcadio Gym Short')]");
    private By addToWishlistButton = By.xpath("//div[@class='product-addto-links']/a/span");
    private By removeProductFromWishlist = By.xpath("//a[@title='Remove This Item']");
    private By removeFromWishlistMessage = By.xpath("//div[@class='message info empty']/span");




    public void navigateToWishListPage (){
        driver.navigate().to(myWishListPageUrl);
    }

    public void clickOnArcadioGymShorts() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(arcadioGymShorts)).click();
    }

    public void clickOnAddToWishlistButton() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(addToWishlistButton)).click();
    }

    public void clickOnRemoveFromWishlist () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(removeProductFromWishlist)).click();
    }

    public String getMessageFromRemoveProductFromWishlist() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(removeFromWishlistMessage)).getText();
    }


}
