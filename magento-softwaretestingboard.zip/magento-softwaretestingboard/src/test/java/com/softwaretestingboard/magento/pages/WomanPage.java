package com.softwaretestingboard.magento.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WomanPage {

    WebDriver driver;
    WebDriverWait wait;

    public WomanPage(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    private String womanPageUrl = "https://magento.softwaretestingboard.com/women.html";

    private By tops = By.xpath("//dl[@id='narrow-by-list2']/dd/ol/li[1]/a");
    private By bottoms = By.xpath("//dl[@id='narrow-by-list2']/dd/ol/li[2]/a");
    private By hoodiesAndSweatshirt = By.xpath("//div[@class='categories-menu']/ul[1]/li[1]");
    private By jackets = By.xpath("//div[@class='categories-menu']/ul[1]/li[2]");
    private By tees = By.xpath("//div[@class='categories-menu']/ul[1]/li[3]");
    private By brasAndTanks = By.xpath("//div[@class='categories-menu']/ul[1]/li[4]");
    private By pants = By.xpath("//div[@class='categories-menu']/ul[2]/li[1]/a");
    private By shorts = By.xpath("//div[@class='categories-menu']/ul[2]/li[2]");
    private By shopNewYoga = By.xpath("//span[text()='Shop New Yoga']");
    private By fourTees = By.xpath("//span[text()='4 tees for the price of 3. Right now']");
    private By discountPants = By.xpath("//a[@class='block-promo womens-pants']/span/span/span");
    private By erinRecommends = By.xpath("//span[text()='Shop Erin Recommends']");
    private By lumaPants = By.xpath("//strong[text()='Luma pants']");
    private By lumaShorts = By.xpath("//strong[text()='Luma shorts']");
    private By lumaBrasTanks = By.xpath("//a[@class='block-promo womens-category-tanks']/span/span[2]");
    private By radiantTee = By.xpath("//a[@title='Radiant Tee']");
    private By breatheEasyTank = By.xpath("//a[@title='Breathe-Easy Tank']");
    private By seleneYogaHoodie = By.xpath("//a[@title='Selene Yoga Hoodie']");
    private By deirdreRelaxedFitCapri = By.xpath("//a[@title='Deirdre Relaxed-Fit Capri']");


    public void navigateToWomanPage() {
        driver.navigate().to(womanPageUrl);
    }

    public void clickOnTops () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(tops)).click();
    }

    public void clickOnBottoms () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(bottoms)).click();
    }

    public void clickOnHoodiesAndSweatshirt () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(hoodiesAndSweatshirt)).click();
    }

    public void clickOnJackets () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(jackets)).click();
    }

    public void clickOnBrasAndTanks () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(brasAndTanks)).click();
    }

    public void clickOnTees () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(tees)).click();
    }

    public void clickOnPants () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(pants)).click();
    }

    public void clickOnShorts () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(shorts)).click();
    }

    public void clickOnShopNewYoga () throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(shopNewYoga)).click();
        Thread.sleep(3000);
        driver.navigate().to(womanPageUrl);
    }

    public void clickOnFourTees () throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(fourTees)).click();
        Thread.sleep(3000);
        driver.navigate().to(womanPageUrl);
    }

    public void clickOnDiscountPants () throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(discountPants)).click();
        Thread.sleep(3000);
        driver.navigate().to(womanPageUrl);
    }

    public void clickOnErinRecommends () throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(erinRecommends)).click();
        Thread.sleep(3000);
        driver.navigate().to(womanPageUrl);
    }

    public void clickOnLumaPants () throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(lumaPants)).click();
        Thread.sleep(3000);
        driver.navigate().to(womanPageUrl);
    }

    public void clickOnLumaShorts () throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(lumaShorts)).click();
        Thread.sleep(3000);
        driver.navigate().to(womanPageUrl);
    }

    public void clickOnLumaBrasTanks () throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(lumaBrasTanks)).click();
        Thread.sleep(3000);
        driver.navigate().to(womanPageUrl);
    }

    public void clickOnRadiantTee () throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(radiantTee)).click();
        Thread.sleep(3000);
        driver.navigate().to(womanPageUrl);
    }

    public void clickOnBreatheEasyTank () throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(breatheEasyTank)).click();
        Thread.sleep(3000);
        driver.navigate().to(womanPageUrl);
    }

    public void clickOnSeleneYogaHoodie () throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(seleneYogaHoodie)).click();
        Thread.sleep(3000);
        driver.navigate().to(womanPageUrl);
    }

    public void clickOnDeirdreRelaxedFitCapri () throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(deirdreRelaxedFitCapri)).click();
        Thread.sleep(3000);
        driver.navigate().to(womanPageUrl);
    }

}
