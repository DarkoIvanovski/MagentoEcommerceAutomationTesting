package com.softwaretestingboard.magento.tests;

import org.testng.annotations.Test;

public class OrdersAndReturnsTest extends BaseTest {

    @Test
    public void testOrderAndReturnsPage() {
        ordersAndReturnPage.navigateToOrdersAndReturnPage();
        ordersAndReturnPage.enterOrdersId("000012727");
        ordersAndReturnPage.enterBillingLastName("Johnson");
        ordersAndReturnPage.selectFindOrderBy("email");
        ordersAndReturnPage.enterEmail("emily.johnson@example.com");
        ordersAndReturnPage.clickOnContinueButton();
    }
}
