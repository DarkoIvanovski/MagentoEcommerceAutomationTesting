package com.softwaretestingboard.magento.tests;

import org.testng.annotations.Test;

public class WhatsNewsTests extends BaseTest {

    @Test
    public void newsInWomenMenu() throws InterruptedException {
        whatsNewPage.navigateToWhatsNewPage();
        whatsNewPage.clickOnHoodiesAndSweatshirtWoman();
        whatsNewPage.clickOnJacketWoman();
        whatsNewPage.clickOnWomenTee();
        whatsNewPage.clickOnWomanBrasAndTanks();
        whatsNewPage.clickOnWomanTanks();
        whatsNewPage.clickOnWomanShorts();
    }

    @Test
    public void newsInMensMenu() throws InterruptedException {
        whatsNewPage.navigateToWhatsNewPage();
        whatsNewPage.clickOnMenHoodiesAndSweatshirt();
        whatsNewPage.clickOnMensJackets();
        whatsNewPage.clickOnMensTees();
        whatsNewPage.clickOnMensTanks();
        whatsNewPage.clickOnMensPants();
        whatsNewPage.clickOnMenShorts();
    }

    @Test
    public void newsInPictures() throws InterruptedException {
        whatsNewPage.navigateToWhatsNewPage();
        whatsNewPage.clickOnShopNewYoga();
        whatsNewPage.clickOnPerformanceFabrics();
        whatsNewPage.clickOnShopEcoFriendly();
    }

    @Test
    public void clickOnProducts() throws InterruptedException {
        whatsNewPage.navigateToWhatsNewPage();
        whatsNewPage.clickOnWayfarerMessengerBag();
        whatsNewPage.clickOnOvernightDuffle();
        whatsNewPage.clickOnSummitWatch();
        whatsNewPage.clickOnDashDigitalWatch();
    }


}
