package com.softwaretestingboard.magento.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WhatsNewPage {

    WebDriver driver;
    WebDriverWait wait;

    public WhatsNewPage(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    private String whatsNewPageUrl = "https://magento.softwaretestingboard.com/what-is-new.html";

    private By hoodiesAndSweatshirtWoman = By.xpath("//div[@class='categories-menu']/ul[1]/li[1]");
    private By jacketWoman = By.xpath("//div[@class='categories-menu']/ul[1]/li[2]");
    private By womenTee = By.xpath("//div[@class='categories-menu']/ul[1]/li[3]");
    private By womanBrasAndTanks = By.xpath("//div[@class='categories-menu']/ul[1]/li[4]");
    private By womanTanks = By.xpath("//div[@class='categories-menu']/ul[1]/li[5]");
    private By womanShorts = By.xpath("//div[@class='categories-menu']/ul[1]/li[6]");
    private By menHoodiesAndSweatshirt = By.xpath("//div[@class='categories-menu']/ul[2]/li[1]");
    private By mensJackets = By.xpath("//div[@class='categories-menu']/ul[2]/li[2]");
    private By mensTees = By.xpath("//div[@class='categories-menu']/ul[2]/li[3]");
    private By mensTanks = By.xpath("//div[@class='categories-menu']/ul[2]/li[4]");
    private By mensPants = By.xpath("//div[@class='categories-menu']/ul[2]/li[5]");
    private By menShorts = By.xpath("//div[@class='categories-menu']/ul[2]/li[6]");
    private By shopNewYoga = By.xpath("//span[text()='Shop New Yoga']");
    private By performanceFabrics = By.xpath("//span[text()='Performance Fabrics']");
    private By shopEcoFriendly = By.xpath("//span[text()='Shop Eco Friendly ']");
    private By wayfarerMessengerBag = By.xpath("//a[@title='Wayfarer Messenger Bag']");
    private By overnightDuffle = By.xpath("//a[@title='Overnight Duffle']");
    private By summitWatch = By.xpath("//a[@title='Summit Watch']");
    private By dashDigitalWatch = By.xpath("//a[@title='Dash Digital Watch']");


    public void navigateToWhatsNewPage() {
        driver.navigate().to(whatsNewPageUrl);
    }

    public void clickOnHoodiesAndSweatshirtWoman() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(hoodiesAndSweatshirtWoman)).click();
        Thread.sleep(1500);
        driver.navigate().to(whatsNewPageUrl);
    }

    public void clickOnJacketWoman() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(jacketWoman)).click();
        Thread.sleep(1500);
        driver.navigate().to(whatsNewPageUrl);
    }

    public void clickOnWomenTee() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(womenTee)).click();
        Thread.sleep(1500);
        driver.navigate().to(whatsNewPageUrl);
    }

    public void clickOnWomanBrasAndTanks() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(womanBrasAndTanks)).click();
        Thread.sleep(1500);
        driver.navigate().to(whatsNewPageUrl);
    }

    public void clickOnWomanTanks() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(womanTanks)).click();
        Thread.sleep(1500);
        driver.navigate().to(whatsNewPageUrl);
    }

    public void clickOnWomanShorts() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(womanShorts)).click();
        Thread.sleep(1500);
        driver.navigate().to(whatsNewPageUrl);
    }

    public void clickOnMenHoodiesAndSweatshirt() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(menHoodiesAndSweatshirt)).click();
        Thread.sleep(1500);
        driver.navigate().to(whatsNewPageUrl);
    }

    public void clickOnMensTees() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(mensTees)).click();
        Thread.sleep(1500);
        driver.navigate().to(whatsNewPageUrl);
    }

    public void clickOnMensJackets() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(mensJackets)).click();
        Thread.sleep(1500);
        driver.navigate().to(whatsNewPageUrl);
    }

    public void clickOnMensTanks() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(mensTanks)).click();
        Thread.sleep(1500);
        driver.navigate().to(whatsNewPageUrl);
    }

    public void clickOnMensPants() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(mensPants)).click();
        Thread.sleep(1500);
        driver.navigate().to(whatsNewPageUrl);
    }
    public void clickOnMenShorts() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(menShorts)).click();
        Thread.sleep(1500);
        driver.navigate().to(whatsNewPageUrl);
    }

    public void clickOnShopNewYoga() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(shopNewYoga)).click();
        Thread.sleep(1500);
        driver.navigate().to(whatsNewPageUrl);
    }

    public void clickOnPerformanceFabrics() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(performanceFabrics)).click();
        Thread.sleep(1500);
        driver.navigate().to(whatsNewPageUrl);
    }

    public void clickOnShopEcoFriendly() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(shopEcoFriendly)).click();
        Thread.sleep(1500);
        driver.navigate().to(whatsNewPageUrl);
    }

    public void clickOnWayfarerMessengerBag() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(wayfarerMessengerBag)).click();
        Thread.sleep(1500);
        driver.navigate().to(whatsNewPageUrl);
    }

    public void clickOnOvernightDuffle() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(overnightDuffle)).click();
        Thread.sleep(1500);
        driver.navigate().to(whatsNewPageUrl);
    }

    public void clickOnSummitWatch() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(summitWatch)).click();
        Thread.sleep(1500);
        driver.navigate().to(whatsNewPageUrl);
    }

    public void clickOnDashDigitalWatch() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(dashDigitalWatch)).click();
        Thread.sleep(1500);
        driver.navigate().to(whatsNewPageUrl);
    }


}
