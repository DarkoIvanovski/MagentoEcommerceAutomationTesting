package com.softwaretestingboard.magento.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;



public class HomePage {

    WebDriver driver;
    WebDriverWait wait;

    public HomePage (WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    private String homePageURL = "https://magento.softwaretestingboard.com/";
    private By supportThisProject = By.xpath("//div[@class='panel wrapper']/div/ul/li[1]/span/a");
    private By signIn = By.xpath("//div[@class='panel wrapper']/div/ul/li[2]/a");
    private By createAnAccount = By.xpath("//div[@class='panel wrapper']/div/ul/li[3]/a");

    private By homeLogo = By.xpath("//a[@class='logo']");

    private By search = By.id("search");
    private By searchMessage = By.xpath("//h1[@class='page-title']/span");


    private By shopNewYoga = By.xpath("//span[@class='action more button']");
    private By pantsOnDiscount = By.xpath("//a[@class='block-promo home-pants']");
    private By threeLumaShirts = By.xpath("//a[@class='block-promo home-t-shirts']/span[2]/span[2]");
    private By takeFromErin = By.xpath("//a[@class='block-promo home-erin']/span[1]/span[2]");
    private By scienceMeetPerformance = By.xpath("//a[@class='block-promo home-performance']/span[1]/span[2]");
    private By shopEcoFriendly = By.xpath("//a[@class='block-promo home-eco']/span/span[2]");


    private By radiantTee = By.xpath("//a[@title='Radiant Tee']");
    private By breatheEasyTank = By.xpath("//a[contains(text(),'Breathe-Easy Tank ')]");
    private By argusAllWeatherTank = By.xpath("//a[@title='Argus All-Weather Tank']");
    private By heroHoodie = By.xpath("//a[@title='Hero Hoodie']");
    private By addToCartItemOne = By.xpath("//*[@id='maincontent']/div[3]/div/div[2]/div[3]/div/div/ol/li[5]/div/div/div[3]/div/div[1]/form/button/span");
    private By cartFusionBackpack = By.xpath("//a[@title='Fusion Backpack' and contains(text(),'Fusion Backpack')]");
    private By addToCartItemTwo = By.xpath("//*[@id='maincontent']/div[3]/div/div[2]/div[3]/div/div/ol/li[6]/div/div/div[3]/div/div[1]/form/button/span");
    private By pushItMessengerBag = By.xpath("//a[@title='Push It Messenger Bag' and contains(text(),'Push It Messenger Bag')]");
    private By clickOnRightBottomMessage = By.xpath("//div[@class='ea-content']/div/a/span");
    private By clickEscapeOnRightBottomMessage = By.xpath("//div[@class='ea-stickybox-hide']");

    private By cartIcon = By.xpath("//a[@class='action showcart']");
    private By deleteButton = By.xpath("//a[@class='action delete']");
    private By okDelete = By.xpath("//button[@class='action-primary action-accept']");

    private By notesLink = By.xpath("//div[@class='footer content']/div/div/ul/li[1]/a");
    private By practiceAPITestingUsingMagentoLink = By.xpath("//div[@class='footer content']/div/div/ul/li[2]/a");
    private By writeForUsLink = By.xpath("//div[@class='footer content']/div/div/ul/li[3]/a");
    private By subscribeLink = By.xpath("//div[@class='footer content']/div/div/ul/li[4]/a");
    private String searchTermsLink = "https://magento.softwaretestingboard.com/search/term/popular/";
    private String privacyAndCookieLink = "https://magento.softwaretestingboard.com/privacy-policy-cookie-restriction-mode";
    private String advancedSearch = "https://magento.softwaretestingboard.com/catalogsearch/advanced/";
    private String ordersAndReturnsLink = "https://magento.softwaretestingboard.com/sales/guest/form/";

    private By itemInCart = By.xpath("//div[@class='items-total']/span");
    private By subtotalPrice = By.xpath("//div[@class='amount price-container']/span/span");
    private By firstProductInCart = By.xpath("//*[@id='mini-cart']/li[1]/div/div/strong/a");
    private By firstProductInCartPrice = By.xpath("//*[@id='mini-cart']/li[1]/div/div/div[1]/div[1]/span/span/span/span");
    private By secondProductInCart = By.xpath("//*[@id='mini-cart']/li[2]/div/div/strong/a");
    private By secondProductInCartPrice = By.xpath("//*[@id='mini-cart']/li[2]/div/div/div[1]/div[1]/span/span/span/span");


    public void navigateToHomePage () {
        driver.navigate().to(homePageURL);
    }

    public void clickOnSupportThisProject () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(supportThisProject)).click();
        driver.navigate().back();
    }

    public void clickOnSignIn () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(signIn)).click();
    }

    public void clickOnCreateAnAccount () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(createAnAccount)).click();
        driver.navigate().back();
    }

    public void clickOnHomeLogoButton () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(homeLogo)).click();
    }

    public void typeInSearchField (String word) {
        WebElement searchField = driver.findElement(search);
        searchField.sendKeys(word);
        searchField.submit();
    }

    public String getSearchFieldResultsMessage() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(searchMessage)).getText();
    }

    public void clearDataInSearchField() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(search)).clear();
        Thread.sleep(1500);
    }


    public void clickOnShopNewYoga() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(shopNewYoga)).click();
        driver.navigate().back();
    }

    public void clickOnPantsOnDiscount() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(pantsOnDiscount)).click();
        driver.navigate().back();
    }

    public void clickOnThreeLumaShirts() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(threeLumaShirts)).click();
        driver.navigate().back();
    }

    public void clickOnTakeFromErin() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(takeFromErin)).click();
        driver.navigate().back();
    }

    public void clickOnScienceMeetPerformance() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(scienceMeetPerformance)).click();
        driver.navigate().back();
    }

    public void clickOnShopEcoFriendly() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(shopEcoFriendly)).click();
        driver.navigate().back();
    }

    public void clickOnNotesLink() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(notesLink)).click();
    }

    public void clickOnPracticeAPITestingUsingMagentoLink() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(practiceAPITestingUsingMagentoLink)).click();
    }

    public void clickOnWriteForUsLink() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(writeForUsLink)).click();
    }

    public void clickOnSubscribeLink() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(subscribeLink)).click();
    }

    public void clickOnSearchTermsLink() throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.get(searchTermsLink);
        Thread.sleep(1000);
        driver.quit();
    }

    public void clickOnPrivacyAndCookieLink() throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.get(privacyAndCookieLink);
        Thread.sleep(1000);
        driver.quit();
    }

    public void clickOnAdvancedSearch() throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.get(advancedSearch);
        Thread.sleep(1000);
        driver.quit();
    }

    public void clickOnOrdersAndReturnsLink() throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.get(ordersAndReturnsLink);
        Thread.sleep(1000);
        driver.quit();
    }

    public void clickOnRadiantTee() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(radiantTee)).click();
        driver.navigate().back();
    }

    public void clickOnBreatheEasyTank() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(breatheEasyTank)).click();
        driver.navigate().back();
    }

    public void clickOnArgusAllWeatherTank() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(argusAllWeatherTank)).click();
        driver.navigate().back();
    }

    public void clickOnHeroHoodie() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(heroHoodie)).click();
        driver.navigate().back();
    }

    public void clickAddToCartFusionBackpack() throws InterruptedException {
        WebElement elementToHover = driver.findElement(cartFusionBackpack);
        Actions actions = new Actions(driver);
        actions.moveToElement(elementToHover).perform();
        Thread.sleep(1000);
        wait.until(ExpectedConditions.visibilityOfElementLocated((addToCartItemOne))).click();
        Thread.sleep(1500);
    }

    public void clickOnAddToCartPushItMessengerBag() throws InterruptedException {
        WebElement elementToHover = driver.findElement(pushItMessengerBag);
        Actions actions = new Actions(driver);
        actions.moveToElement(elementToHover).perform();
        Thread.sleep(1000);
        wait.until(ExpectedConditions.visibilityOfElementLocated(addToCartItemTwo)).click();
        Thread.sleep(1500);
    }

    public void clickOnCartIcon() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(cartIcon)).click();
    }

    public void clickOnDeleteButton() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(deleteButton)).click();
    }

    public void clickOkOnDeleteMessage() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(okDelete)).click();
    }

    public String getItemsInCartMessage() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(itemInCart)).getText();
    }

    public String getSubtotalPriceMessage() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(subtotalPrice)).getText();
    }

    public String getFirstProductInCart() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(firstProductInCart)).getText();
    }

    public String getFirstProductInCartPrice() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(firstProductInCartPrice)).getText();
    }

    public String getSecondProductInCart() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(secondProductInCart)).getText();
    }

    public String getSecondProductInCartPrice() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(secondProductInCartPrice)).getText();
    }

    public void clickOnRightBottomPopUpMessage() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(clickOnRightBottomMessage)).click();
        Thread.sleep(1500);
        driver.navigate().to(homePageURL);
    }

    public void clickEscapeOnRightBottomPopUpMessage() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(clickEscapeOnRightBottomMessage)).click();
    }


}
