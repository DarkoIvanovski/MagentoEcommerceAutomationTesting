package com.softwaretestingboard.magento.tests;

import org.testng.annotations.Test;

public class ShowProductTests extends BaseTest {

    @Test
    public void showProductAsListAndGrid() throws InterruptedException {
        showProductPage.navigateToMenJacketPage();
        showProductPage.clickOnListProduct();
        showProductPage.clickOnGridMode();
    }

    @Test
    public void sortProductBy() throws InterruptedException {
        showProductPage.navigateToMenJacketPage();
        showProductPage.sortBy("position");
        showProductPage.sortBy("name");
        showProductPage.sortBy("price");
    }

    @Test
    public void showProductByAscendingAndDescending() {
        showProductPage.navigateToMenJacketPage();
        showProductPage.orderByAscendingDescending();
    }

    @Test
    public void showProductPerPage() throws InterruptedException {
        showProductPage.navigateToMenJacketPage();
        showProductPage.showProductPerPage("12");
        showProductPage.showProductPerPage("24");
        showProductPage.showProductPerPage("36");
    }

}
