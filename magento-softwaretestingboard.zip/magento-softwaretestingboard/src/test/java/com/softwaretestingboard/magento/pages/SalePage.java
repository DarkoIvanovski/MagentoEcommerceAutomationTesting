package com.softwaretestingboard.magento.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SalePage {

    WebDriver driver;
    WebDriverWait wait;

   public SalePage (WebDriver driver, WebDriverWait wait) {
       this.driver = driver;
       this.wait = wait;
   }

   private String salePageUrl = "https://magento.softwaretestingboard.com/sale.html";

   private By womenHoodiesAndSweatshirt = By.xpath("//div[@class='categories-menu']/ul[1]/li[1]");
   private By womenJackets = By.xpath("//div[@class='categories-menu']/ul[1]/li[2]");
   private By womenTees = By.xpath("//div[@class='categories-menu']/ul[1]/li[3]");
   private By womenBrasAndTanks = By.xpath("//div[@class='categories-menu']/ul[1]/li[4]");
   private By womenPants = By.xpath("//div[@class='categories-menu']/ul[1]/li[5]");
   private By womenShorts = By.xpath("//div[@class='categories-menu']/ul[1]/li[6]");
   private By mensHoodiesAndSweatshirt = By.xpath("//div[@class='categories-menu']/ul[2]/li[1]");
   private By mensJackets = By.xpath("//div[@class='categories-menu']/ul[2]/li[2]");
   private By mensTees = By.xpath("//div[@class='categories-menu']/ul[2]/li[3]");
   private By mensPants = By.xpath("//div[@class='categories-menu']/ul[2]/li[4]");
   private By mensShorts = By.xpath("//div[@class='categories-menu']/ul[2]/li[5]");
   private By bags = By.xpath("//div[@class='categories-menu']/ul[3]/li[1]");
   private By fitnessEquipment = By.xpath("//div[@class='categories-menu']/ul[3]/li[2]");
   private By shopWomensDeals = By.xpath("//span[text()='Shop Women’s Deals']");
   private By shopMensDeals = By.xpath("//span[text()='Shop Men’s Deals']");
   private By shopLumaGear = By.xpath("//span[text()='Shop Luma Gear']");
   private By teesOnSale = By.xpath("//span[text()='Tees on sale']");


   public void navigateToSalePage() {
       driver.navigate().to(salePageUrl);
   }

   public void clickOnWomenHoodiesAndSweatshirt() throws InterruptedException {
       wait.until(ExpectedConditions.visibilityOfElementLocated(womenHoodiesAndSweatshirt)).click();
       Thread.sleep(1500);
       driver.navigate().to(salePageUrl);
   }
    public void clickOnWomenJackets() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(womenJackets)).click();
        Thread.sleep(1500);
        driver.navigate().to(salePageUrl);
    }
    public void clickOnwWomenTees() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(womenTees)).click();
        Thread.sleep(1500);
        driver.navigate().to(salePageUrl);
    }
    public void clickOnWomenBrasAndTanks() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(womenBrasAndTanks)).click();
        Thread.sleep(1500);
        driver.navigate().to(salePageUrl);
    }
    public void clickOnWomenPants() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(womenPants)).click();
        Thread.sleep(1500);
        driver.navigate().to(salePageUrl);
    }
    public void clickOnWomenShorts() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(womenShorts)).click();
        Thread.sleep(1500);
        driver.navigate().to(salePageUrl);
    }
    public void clickOnMensHoodiesAndSweatshirt() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(mensHoodiesAndSweatshirt)).click();
        Thread.sleep(1500);
        driver.navigate().to(salePageUrl);
    }
    public void clickOnMensJackets() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(mensJackets)).click();
        Thread.sleep(1500);
        driver.navigate().to(salePageUrl);
    }
    public void clickOnMensTees() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(mensTees)).click();
        Thread.sleep(1500);
        driver.navigate().to(salePageUrl);
    }
    public void clickOnMensPants() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(mensPants)).click();
        Thread.sleep(1500);
        driver.navigate().to(salePageUrl);
    }
    public void clickOnMensShorts() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(mensShorts)).click();
        Thread.sleep(1500);
        driver.navigate().to(salePageUrl);
    }
    public void clickOnBags() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(bags)).click();
        Thread.sleep(1500);
        driver.navigate().to(salePageUrl);
    }
    public void clickOnFitnessEquipment() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(fitnessEquipment)).click();
        Thread.sleep(1500);
        driver.navigate().to(salePageUrl);
    }
    public void clickOnShopWomenDeals() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(shopWomensDeals)).click();
        Thread.sleep(1500);
        driver.navigate().to(salePageUrl);
    }
    public void clickOnShopMensDeals() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(shopMensDeals)).click();
        Thread.sleep(1500);
        driver.navigate().to(salePageUrl);
    }
    public void clickOnShopLumaGear() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(shopLumaGear)).click();
        Thread.sleep(1500);
        driver.navigate().to(salePageUrl);
    }
    public void clickOnTeesOnSale() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(teesOnSale)).click();
        Thread.sleep(1500);
        driver.navigate().to(salePageUrl);
    }






}
