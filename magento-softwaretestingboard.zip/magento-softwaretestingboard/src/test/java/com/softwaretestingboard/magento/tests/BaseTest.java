package com.softwaretestingboard.magento.tests;

import com.softwaretestingboard.magento.pages.*;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import java.time.Duration;

public class BaseTest {

    WebDriver driver;
    WebDriverWait wait;
    JavascriptExecutor js;
    private int duration = 10;


    final String BASE_URL = "https://magento.softwaretestingboard.com/";

    public HomePage homePage;
    public WhatsNewPage whatsNewPage;
    public WomanPage womanPage;
    public MenPage menPage;
    public GearPage gearPage;
    public TrainingPage trainingPage;
    public SalePage salePage;
    public MainMenuPage mainMenuPage;
    public CreateAnAccountPage createAnAccountPage;
    public SignInPage signInPage;
    public AccountPage accountPage;
    public AddProductToWishlistPage addProductToWishlistPage;
    public ReviewProductPage reviewProductPage;
    public ShoppingCart shoppingCart;
    public OrderProductPage orderProductPage;
    public CompareProductsPage compareProductsPage;
    public FilterPage filterPage;
    public ShowProductPage showProductPage;
    public PrivacyPolicyPage privacyPolicyPage;
    public AdvancedSearchPage advancedSearchPage;
    public OrdersAndReturnPage ordersAndReturnPage;






    @BeforeMethod
    public void setUp() {
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--start-maximized", "--incognito", "--headless");
        driver = new ChromeDriver(options);
        wait = new WebDriverWait(driver, Duration.ofSeconds(duration));
        js = (JavascriptExecutor) driver;
        homePage = new HomePage (driver, wait);
        whatsNewPage = new WhatsNewPage (driver, wait);
        womanPage = new WomanPage (driver, wait);
        menPage = new MenPage (driver, wait);
        gearPage = new GearPage (driver, wait);
        trainingPage = new TrainingPage (driver, wait);
        salePage = new SalePage (driver, wait);
        mainMenuPage = new MainMenuPage (driver, wait);
        createAnAccountPage = new CreateAnAccountPage (driver, wait);
        signInPage = new SignInPage (driver, wait);
        accountPage = new AccountPage (driver, wait);
        addProductToWishlistPage = new AddProductToWishlistPage(driver, wait);
        reviewProductPage = new ReviewProductPage (driver, wait);
        shoppingCart = new ShoppingCart (driver, wait);
        orderProductPage = new OrderProductPage (driver, wait);
        compareProductsPage = new CompareProductsPage (driver, wait);
        filterPage = new FilterPage (driver, wait);
        showProductPage = new ShowProductPage (driver, wait);
        privacyPolicyPage = new PrivacyPolicyPage (driver, wait);
        advancedSearchPage = new AdvancedSearchPage (driver, wait);
        ordersAndReturnPage = new OrdersAndReturnPage (driver, wait);
        driver.get(BASE_URL);
        driver.manage().window().maximize();
    }

    @AfterMethod
    public void tearDown(){
        driver.quit();
    }


}
