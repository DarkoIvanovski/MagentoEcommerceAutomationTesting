package com.softwaretestingboard.magento.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CreateAnAccountPage {

    WebDriver driver;
    WebDriverWait wait;

    public CreateAnAccountPage(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    private String crateAnAccountPageURL = "https://magento.softwaretestingboard.com/customer/account/create/";

    private By enterFirstName = By.id("firstname");
    private By enterLastName = By.id("lastname");
    private By enterEmailAddress = By.id("email_address");
    private By enterPassword = By.id("password");
    private By passwordStrengthMessage = By.id("password-strength-meter-label");
    private By enterConfirmPassword = By.id("password-confirmation");
    private By createAnAccountButton = By.xpath("//button[@title='Create an Account']");

    public void navigateToSignUpPage() {
        driver.navigate().to(crateAnAccountPageURL);
    }

    public void enterFirstName(String firstName) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(enterFirstName)).sendKeys(firstName);
    }

    public void enterLastName(String lastName) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(enterLastName)).sendKeys(lastName);
    }

    public void enterEmailAddress(String emailAddress) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(enterEmailAddress)).sendKeys(emailAddress);
    }

    public void enterPassword(String password) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(enterPassword)).sendKeys(password);
    }

    public String getStrengthPasswordMessage() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(passwordStrengthMessage)).getText();
    }

    public void enterConfirmPassword(String confirmPassword) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(enterConfirmPassword)).sendKeys(confirmPassword);
    }

    public void clickOnCreateAnAccountButton() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(createAnAccountButton)).click();
    }
}
