package com.softwaretestingboard.magento.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class MenPage {

    WebDriver driver;
    WebDriverWait wait;

    public MenPage(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    private String menPageUrl = "https://magento.softwaretestingboard.com/men.html";

    private By tops = By.xpath("//dl[@id='narrow-by-list2']/dd/ol/li[1]/a");
    private By bottoms = By.xpath("//dl[@id='narrow-by-list2']/dd/ol/li[2]/a");
    private By hoodiesAndSweatshirt = By.xpath("//div[@class='categories-menu']/ul[1]/li[1]/a");
    private By jackets = By.xpath("//div[@class='categories-menu']/ul[1]/li[2]/a");
    private By tees = By.xpath("//div[@class='categories-menu']/ul[1]/li[3]/a");
    private By tanks = By.xpath("//div[@class='categories-menu']/ul[1]/li[4]/a");
    private By pants = By.xpath("//div[@class='categories-menu']/ul[2]/li[1]/a");
    private By shorts = By.xpath("//div[@class='categories-menu']/ul[2]/li[2]/a");
    private By shopPerformance = By.xpath("//span[text()='Shop Performance']");
    private By threeShirts = By.xpath("//span[text()='Buy 3 Luma tees, get 4 instead']");
    private By discountPants = By.xpath("//a[@class='block-promo mens-pants']/span/span[2]");
    private By lumaShorts = By.xpath("//a[@class='block-promo mens-category-shorts']/span/span[2]");
    private By lumaTees = By.xpath("//a[@class='block-promo mens-category-tees']/span/span[2]");
    private By lumaHoodies = By.xpath("//a[@class='block-promo mens-category-hoodies']/span/span[2]");
    private By argusAllWeatherTank = By.xpath("//a[@title='Argus All-Weather Tank']");
    private By heroHoodie = By.xpath("//a[@title='Hero Hoodie']");
    private By meteorWorkoutShorts = By.xpath("//a[@title='Meteor Workout Short']");
    private By geoInsulatedJoggingPant = By.xpath("//a[@title='Geo Insulated Jogging Pant']");


    public void navigateToMenPage() {
        driver.navigate().to(menPageUrl);
    }

    public void clickOnTops() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(tops)).click();
    }
    public void clickOnBottoms() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(bottoms)).click();
    }
    public void clickOnHoodiesAndSweatshirt() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(hoodiesAndSweatshirt)).click();
    }
    public void clickOnJackets() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(jackets)).click();
    }
    public void clickOnTees() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(tees)).click();
    }
    public void clickOnTanks() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(tanks)).click();
    }
    public void clickOnPants() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(pants)).click();
    }
    public void clickOnShorts() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(shorts)).click();
    }
    public void clickOnShopPerformance() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(shopPerformance)).click();
        Thread.sleep(1500);
        driver.navigate().to(menPageUrl);
    }
    public void clickOnThreeShirts() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(threeShirts)).click();
        Thread.sleep(1500);
        driver.navigate().to(menPageUrl);
    }
    public void clickOnDiscountPants() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(discountPants)).click();
        Thread.sleep(1500);
        driver.navigate().to(menPageUrl);
    }
    public void clickOnLumaShorts() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(lumaShorts)).click();
        Thread.sleep(1500);
        driver.navigate().to(menPageUrl);
    }
    public void clickOnLumaTees() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(lumaTees)).click();
        Thread.sleep(1500);
        driver.navigate().to(menPageUrl);
    }
    public void clickOnLumaHoodies() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(lumaHoodies)).click();
        Thread.sleep(1500);
        driver.navigate().to(menPageUrl);
    }
    public void clickOnArgusAllWeatherTank() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(argusAllWeatherTank)).click();
        Thread.sleep(1500);
        driver.navigate().to(menPageUrl);
    }
    public void clickOnHeroHoodie() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(heroHoodie)).click();
        Thread.sleep(1500);
        driver.navigate().to(menPageUrl);
    }
    public void clickOnMeteorWorkoutShorts() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(meteorWorkoutShorts)).click();
        Thread.sleep(1500);
        driver.navigate().to(menPageUrl);
    }
    public void clickOnGeoInsulatedJoggingPant() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(geoInsulatedJoggingPant)).click();
        Thread.sleep(1500);
        driver.navigate().to(menPageUrl);
    }


}
