package com.softwaretestingboard.magento.tests;

import org.testng.annotations.Test;

public class WomenTests extends BaseTest {

    @Test
    public void shopByCategory() {
        womanPage.navigateToWomanPage();
        womanPage.clickOnTops();
        womanPage.navigateToWomanPage();
        womanPage.clickOnBottoms();
        womanPage.navigateToWomanPage();
        womanPage.clickOnHoodiesAndSweatshirt();
        womanPage.navigateToWomanPage();
        womanPage.clickOnJackets();
        womanPage.navigateToWomanPage();
        womanPage.clickOnTees();
        womanPage.navigateToWomanPage();
        womanPage.clickOnBrasAndTanks();
        womanPage.navigateToWomanPage();
        womanPage.clickOnPants();
        womanPage.navigateToWomanPage();
        womanPage.clickOnShorts();
        womanPage.navigateToWomanPage();
    }

    @Test
    public void shopByHeaderImages() throws InterruptedException {
        womanPage.navigateToWomanPage();
        womanPage.clickOnShopNewYoga();
        womanPage.clickOnFourTees();
        womanPage.clickOnDiscountPants();
        womanPage.clickOnErinRecommends();
        womanPage.clickOnLumaPants();
        womanPage.clickOnLumaShorts();
        womanPage.clickOnLumaBrasTanks();
    }

    @Test
    public void hotSellersProducts() throws InterruptedException {
        womanPage.navigateToWomanPage();
        womanPage.clickOnRadiantTee();
        womanPage.clickOnBreatheEasyTank();
        womanPage.clickOnSeleneYogaHoodie();
        womanPage.clickOnDeirdreRelaxedFitCapri();
    }
}
