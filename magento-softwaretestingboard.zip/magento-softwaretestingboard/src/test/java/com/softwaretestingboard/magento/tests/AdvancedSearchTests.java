package com.softwaretestingboard.magento.tests;

import org.testng.annotations.Test;

public class AdvancedSearchTests extends BaseTest {

    @Test
    public void testAdvancedSearchPage() {
        advancedSearchPage.navigateToAdvancedSearchPage();
        advancedSearchPage.enterProductName("Proteus Fitness Jackshirt");
        advancedSearchPage.enterSkuCode("MJ12");
        advancedSearchPage.enterPriceFrom("40");
        advancedSearchPage.enterPriceTo("50");
        advancedSearchPage.clickOnSearchButton();
    }
}
