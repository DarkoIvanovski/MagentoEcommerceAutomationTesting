package com.softwaretestingboard.magento.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class GearPage {

    WebDriver driver;
    WebDriverWait wait;

    public GearPage(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    private String gearPageUrl = "https://magento.softwaretestingboard.com/gear.html";

    private By bags = By.xpath("//dl[@id='narrow-by-list2']/dd/ol/li[1]/a");
    private By fitnessEquipment = By.xpath("//dl[@id='narrow-by-list2']/dd/ol/li[2]/a");
    private By watches = By.xpath("//dl[@id='narrow-by-list2']/dd/ol/li[1]/a");
    private By shopYogaKit = By.xpath("//span[text()='Shop Yoga Kit']");
    private By shopFitness = By.xpath("//span[text()='Shop Fitness']");
    private By hereToYou = By.xpath("//a[@class='block-promo gear-equipment']/span/span[1]");
    private By shopBags = By.xpath("//span[text()='Shop Bags']");
    private By shopEquipment = By.xpath("//span[text()='Shop Equipment']");
    private By shopWatches = By.xpath("//span[text()='Shop Watches']");
    private By fusionBackpack = By.xpath("//a[@title='Fusion Backpack']");
    private By pushItMessengerBag = By.xpath("//a[@title='Push It Messenger Bag']");
    private By affirmWaterBottle = By.xpath("//a[@title='Affirm Water Bottle ']");
    private By spriteYogaCompanionKit = By.xpath("//a[@title='Sprite Yoga Companion Kit']");


    public void navigateToGearPage () {
        driver.navigate().to(gearPageUrl);
    }

    public void clickOnBags() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(bags)).click();
        Thread.sleep(1500);
        driver.navigate().to(gearPageUrl);
    }

    public void clickOnFitnessEquipment() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(fitnessEquipment)).click();
        Thread.sleep(1500);
        driver.navigate().to(gearPageUrl);
    }

    public void clickOnWatches() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(watches)).click();
        Thread.sleep(1500);
        driver.navigate().to(gearPageUrl);
    }

    public void clickOnShopYogaKit() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(shopYogaKit)).click();
        Thread.sleep(1500);
        driver.navigate().to(gearPageUrl);
    }

    public void clickOnShopFitness() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(shopFitness)).click();
        Thread.sleep(1500);
        driver.navigate().to(gearPageUrl);
    }

    public void clickOnHereToYou() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(hereToYou)).click();
        Thread.sleep(1500);
        driver.navigate().to(gearPageUrl);
    }

    public void clickOnShopBags() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(shopBags)).click();
        Thread.sleep(1500);
        driver.navigate().to(gearPageUrl);
    }

    public void clickOnShopEquipment() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(shopEquipment)).click();
        Thread.sleep(1500);
        driver.navigate().to(gearPageUrl);
    }

    public void clickOnShopWatches() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(shopWatches)).click();
        Thread.sleep(1500);
        driver.navigate().to(gearPageUrl);
    }

    public void clickOnFusionBackpack() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(fusionBackpack)).click();
        Thread.sleep(1500);
        driver.navigate().to(gearPageUrl);
    }

    public void clickOnPushItMessengerBag() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(pushItMessengerBag)).click();
        Thread.sleep(1500);
        driver.navigate().to(gearPageUrl);
    }

    public void clickOnAffirmWaterBottle() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(affirmWaterBottle)).click();
        Thread.sleep(1500);
        driver.navigate().to(gearPageUrl);
    }

    public void clickOnSpriteYogaCompanionKit() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(spriteYogaCompanionKit)).click();
        Thread.sleep(1500);
        driver.navigate().to(gearPageUrl);
    }




}
