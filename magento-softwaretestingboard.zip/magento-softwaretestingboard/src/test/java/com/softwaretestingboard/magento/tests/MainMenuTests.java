package com.softwaretestingboard.magento.tests;

import org.testng.annotations.Test;

public class MainMenuTests extends BaseTest {

    @Test
    public void testMainMenu () throws InterruptedException {
        homePage.navigateToHomePage();
        mainMenuPage.clickOnWhatsNew();
        mainMenuPage.clickOnWomanMenu();
        mainMenuPage.clickOnWomenTopsMenu();
        mainMenuPage.clickOnWomenTopsJacketsMenu();
        mainMenuPage.clickOnWomenTopsHoodiesAndSweatshirtMenu();
        mainMenuPage.clickOnWomenTopsTeesMenu();
        mainMenuPage.clickOnWomenTopsBrasAndTanksMenu();
        mainMenuPage.clickOnWomenBottomsMenu();
        mainMenuPage.clickOnWomenBottomsPantsMenu();
        mainMenuPage.clickOnWomenBottomsShortsMenu();
        mainMenuPage.clickOnMenMenu();
        mainMenuPage.clickOnMenTopsMenu();
        mainMenuPage.clickOnMenTopsJacketMenu();
        mainMenuPage.clickOnMenTopsHoodiesAndSweatShirtMenu();
        mainMenuPage.clickOnMenTopsTeesMenu();
        mainMenuPage.clickOnMenTopsTanksMenu();
        mainMenuPage.clickOnMenBottomsMenu();
        mainMenuPage.clickOnMenBottomsPantsMenu();
        mainMenuPage.clickOnMenBottomsShortsMenu();
        mainMenuPage.clickOnGearMenu();
        mainMenuPage.clickOnGearBagsMenu();
        mainMenuPage.clickOnGearFitnessEquipmentMenu();
        mainMenuPage.clickOnGearWatchesMenu();
        mainMenuPage.clickOnTrainingMenu();
        mainMenuPage.clickOnTrainingVideoDownloadMenu();
        mainMenuPage.clickOnSale();
    }
}
