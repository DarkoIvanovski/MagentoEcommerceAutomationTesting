package com.softwaretestingboard.magento.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TrainingPage {

    WebDriver driver;
    WebDriverWait wait;

    public TrainingPage(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    private String trainingPageUrl = "https://magento.softwaretestingboard.com/training.html";

    private By videoDownload = By.xpath("//a[text()='Video Download']");
    private By motivateYourSelf = By.xpath("//a[@class='block-promo training-main']/span/strong/span[1]");
    private By beforeCreatingLuma = By.xpath("//a[@class='block-promo training-erin']/span/strong");
    private By videos = By.xpath("//span[text()='Videos']");

    public void navigateToTrainingPage() {
        driver.navigate().to(trainingPageUrl);
    }

    public void clickOnVideoDownload() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(videoDownload)).click();
        Thread.sleep(1500);
        driver.navigate().to(trainingPageUrl);
    }

    public void clickOnMotivateYourSelf() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(motivateYourSelf)).click();
        Thread.sleep(1500);
        driver.navigate().to(trainingPageUrl);
    }

    public void clickOnBeforeCreatingLuma() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(beforeCreatingLuma)).click();
        Thread.sleep(1500);
        driver.navigate().to(trainingPageUrl);
    }

    public void clickOnVideos() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(videos)).click();
        Thread.sleep(1500);
        driver.navigate().to(trainingPageUrl);
    }

}
