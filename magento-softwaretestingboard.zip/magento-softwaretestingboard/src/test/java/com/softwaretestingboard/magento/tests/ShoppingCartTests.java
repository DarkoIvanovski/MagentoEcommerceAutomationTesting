package com.softwaretestingboard.magento.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class ShoppingCartTests extends BaseTest {

    @Test
    public void editProductQuantityInCart() throws InterruptedException {
        homePage.clickOnSignIn();
        signInPage.enterUserEmail("emily.johnson@example.com");
        signInPage.enterUserPassword("T3@c0dEr");
        signInPage.clickOnSignInButton();
        menPage.navigateToMenPage();
        menPage.clickOnPants();
        shoppingCart.clickOnAetherGymPant();
        shoppingCart.selectSize33();
        shoppingCart.selectBrownColor();
        orderProductPage.clickOnAddToCartButton();
        homePage.clickOnCartIcon();
        shoppingCart.clickOnViewAndEditCard();
        shoppingCart.navigateToShoppingCart();
        shoppingCart.editQuantity("3");
        shoppingCart.clickOnUpdateShoppingCartButton();
    }

    @Test
    public void addDiscountCode() throws InterruptedException {
        homePage.clickOnSignIn();
        signInPage.enterUserEmail("emily.johnson@example.com");
        signInPage.enterUserPassword("T3@c0dEr");
        signInPage.clickOnSignInButton();
        menPage.navigateToMenPage();
        menPage.clickOnPants();
        shoppingCart.clickOnAetherGymPant();
        shoppingCart.selectSize33();
        shoppingCart.selectBrownColor();
        orderProductPage.clickOnAddToCartButton();
        homePage.clickOnCartIcon();
        shoppingCart.clickOnViewAndEditCard();
        shoppingCart.navigateToShoppingCart();
        shoppingCart.clickOnApplyDiscountCode();
        shoppingCart.enterDiscountCode("20poff");
        shoppingCart.clickOnApplyDiscountCodeButton();
        Assert.assertEquals(shoppingCart.getDiscountCodeMessage(),"You used coupon code \"20poff\".");
    }

    @Test
    public void addProductToCart() throws InterruptedException {
        homePage.clickOnSignIn();
        signInPage.enterUserEmail("emily.johnson@example.com");
        signInPage.enterUserPassword("T3@c0dEr");
        signInPage.clickOnSignInButton();
        menPage.navigateToMenPage();
        menPage.clickOnPants();
        shoppingCart.clickOnAetherGymPant();
        shoppingCart.selectSize33();
        shoppingCart.selectBrownColor();
        orderProductPage.clickOnAddToCartButton();
        homePage.clickOnCartIcon();
        shoppingCart.clickOnViewAndEditCard();
        shoppingCart.navigateToShoppingCart();
        shoppingCart.addToCartProduct();
        shoppingCart.clickOnUpdateShoppingCartButton();
    }

    @Test
    public void moveToWishlistProductTwo() throws InterruptedException {
        homePage.clickOnSignIn();
        signInPage.enterUserEmail("emily.johnson@example.com");
        signInPage.enterUserPassword("T3@c0dEr");
        signInPage.clickOnSignInButton();
        menPage.navigateToMenPage();
        menPage.clickOnPants();
        shoppingCart.clickOnAetherGymPant();
        shoppingCart.selectSize33();
        shoppingCart.selectBrownColor();
        orderProductPage.clickOnAddToCartButton();
        homePage.clickOnCartIcon();
        shoppingCart.clickOnViewAndEditCard();
        shoppingCart.navigateToShoppingCart();
        js.executeScript("window.scrollBy(0, 500)","");
        shoppingCart.clickOnMoveToWishlistProductTwo();
        Assert.assertEquals(shoppingCart.getMoveToWishlistMessage(),"Zing Jump Rope has been moved to your wish list.");
        shoppingCart.clickOnUpdateShoppingCartButton();
    }

    @Test
    public void editItemParameters() throws InterruptedException {
        homePage.clickOnSignIn();
        signInPage.enterUserEmail("emily.johnson@example.com");
        signInPage.enterUserPassword("T3@c0dEr");
        signInPage.clickOnSignInButton();
        menPage.navigateToMenPage();
        menPage.clickOnPants();
        shoppingCart.clickOnAetherGymPant();
        shoppingCart.selectSize33();
        shoppingCart.selectBrownColor();
        orderProductPage.clickOnAddToCartButton();
        homePage.clickOnCartIcon();
        shoppingCart.clickOnViewAndEditCard();
        shoppingCart.navigateToShoppingCart();
        js.executeScript("window.scrollBy(0, 500)","");
        shoppingCart.clickOnEditParameters();
        shoppingCart.clickOnSize36();
        shoppingCart.clickOnBlueColor();
        js.executeScript("window.scrollBy(0, 500)","");
        orderProductPage.selectQuantity("2");
        shoppingCart.clickOnUpdateCartButton();
        shoppingCart.navigateToShoppingCart();
        shoppingCart.clickOnUpdateShoppingCartButton();
    }

    @Test
    public void clickOnProceedToCheckoutInShoppingCart() throws InterruptedException {
        homePage.clickOnSignIn();
        signInPage.enterUserEmail("emily.johnson@example.com");
        signInPage.enterUserPassword("T3@c0dEr");
        signInPage.clickOnSignInButton();
        menPage.navigateToMenPage();
        menPage.clickOnPants();
        shoppingCart.clickOnAetherGymPant();
        shoppingCart.selectSize33();
        shoppingCart.selectBrownColor();
        orderProductPage.clickOnAddToCartButton();
        homePage.clickOnCartIcon();
        shoppingCart.clickOnViewAndEditCard();
        shoppingCart.navigateToShoppingCart();
        js.executeScript("window.scrollBy(0, 500)","");
        shoppingCart.clickOnProceedToCheckoutButton();
    }

    @Test
    public void deleteProductFromShoppingCart() throws InterruptedException {
        homePage.clickOnSignIn();
        signInPage.enterUserEmail("emily.johnson@example.com");
        signInPage.enterUserPassword("T3@c0dEr");
        signInPage.clickOnSignInButton();
        menPage.navigateToMenPage();
        menPage.clickOnPants();
        shoppingCart.clickOnAetherGymPant();
        shoppingCart.selectSize33();
        shoppingCart.selectBrownColor();
        orderProductPage.clickOnAddToCartButton();
        homePage.clickOnCartIcon();
        shoppingCart.clickOnViewAndEditCard();
        shoppingCart.navigateToShoppingCart();
        shoppingCart.clickOnDeleteButton();
    }

}
