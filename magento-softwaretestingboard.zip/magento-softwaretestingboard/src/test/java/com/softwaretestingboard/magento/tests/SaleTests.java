package com.softwaretestingboard.magento.tests;

import org.testng.annotations.Test;

public class SaleTests extends BaseTest {

    @Test
    public void shopByCategory() throws InterruptedException {
        salePage.navigateToSalePage();
        salePage.clickOnWomenHoodiesAndSweatshirt();
        salePage.clickOnWomenJackets();
        salePage.clickOnwWomenTees();
        salePage.clickOnWomenBrasAndTanks();
        salePage.clickOnWomenPants();
        salePage.clickOnWomenShorts();
        salePage.clickOnMensHoodiesAndSweatshirt();
        salePage.clickOnMensJackets();
        salePage.clickOnMensTees();
        salePage.clickOnMensPants();
        salePage.clickOnMensShorts();
        salePage.clickOnBags();
        salePage.clickOnFitnessEquipment();
    }

    @Test
    public void shopByHeaderImages() throws InterruptedException {
        salePage.navigateToSalePage();
        salePage.clickOnShopWomenDeals();
        salePage.clickOnShopMensDeals();
        salePage.clickOnShopLumaGear();
        salePage.clickOnTeesOnSale();
    }
}
