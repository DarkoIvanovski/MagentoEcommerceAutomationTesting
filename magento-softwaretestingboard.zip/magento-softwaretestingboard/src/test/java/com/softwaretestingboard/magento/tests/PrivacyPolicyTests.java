package com.softwaretestingboard.magento.tests;

import org.testng.annotations.Test;

public class PrivacyPolicyTests extends BaseTest {

    @Test
    public void testPrivacyPolicyPage() {
        privacyPolicyPage.navigateToPrivacyPolicyPage();
        privacyPolicyPage.clickOnLumaPrivacyPolicy();
        privacyPolicyPage.clickOnTheInformationWeCollect();
        privacyPolicyPage.clickOnHowWeUseTheInformationWeCollect();
        privacyPolicyPage.clickOnSecurity();
        privacyPolicyPage.clickOnOthersWithWhomWeShareYourInformation();
        privacyPolicyPage.clickOnYourChoicesRegardingUseOfTheInformationWeCollect();
        privacyPolicyPage.clickOnYourCaliforniaPrivacyRights();
        privacyPolicyPage.clickOnCookiesWebBeaconsAndHowWeUseThem();
        privacyPolicyPage.clickOnListOfCookiesWeCollect();
        privacyPolicyPage.clickOnOnlineAccountRegistration();
        privacyPolicyPage.clickOnEmails();
        privacyPolicyPage.clickOnAcceptance();
        privacyPolicyPage.clickOnQuestionsForLuma();
        privacyPolicyPage.clickOnContactUs();
    }


}
