package com.softwaretestingboard.magento.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class FilterPage {

    WebDriver driver;
    WebDriverWait wait;

    public FilterPage(WebDriver driver, WebDriverWait wait){
        this.driver = driver;
        this.wait = wait;
    }

    private String womanBrasAndTanksPageUrl = "https://magento.softwaretestingboard.com/women/tops-women/tanks-women.html";
    private By style = By.xpath("//div[text()='Style']");
    private By size = By.xpath("//div[text()='Size']");
    private By climate = By.xpath("//div[text()='Climate']");
    private By color = By.xpath("//div[text()='Color']");
    private By ecoCollection = By.xpath("//div[text()='Eco Collection']");
    private By erinRecommends = By.xpath("//div[text()='Erin Recommends']");
    private By material = By.xpath("//div[text()='Material']");
    private By newOptiion = By.xpath("//div[text()='New']");
    private By pattern = By.xpath("//div[text()='Pattern']");
    private By performanceFabric = By.xpath("//div[text()='Performance Fabric']");
    private By price = By.xpath("//div[text()='Price']");
    private By sale = By.xpath("//div[text()='Sale']");
    private By tankStyle =By.xpath("//div[@id='narrow-by-list']/div[1]/div[2]/ol/li[2]/a");
    private By lSize = By.xpath("//div[@id='narrow-by-list']/div[1]/div[2]/div/div/a[4]/div");
    private By indoor = By.xpath("//div[@id='narrow-by-list']/div[1]/div[2]/ol/li[1]/a");
    private By noEcoCollection = By.xpath("//div[@id='narrow-by-list']/div[2]/div[2]/ol/li[2]/a");
    private By erinRecommendation = By.xpath("//div[@id='narrow-by-list']/div[2]/div[2]/ol/li[1]/a");
    private By yesPerformanceFabric  = By.xpath("//div[@id='narrow-by-list']/div[5]/div[2]/ol/li[1]/a");
    private By deleteTank = By.xpath("//a[@title='Remove Style Tank']");
    private By deleteSizeL = By.xpath("//a[@title='Remove Size L']");
    private By deleteClimate = By.xpath("//a[@title='Remove Climate Indoor']");
    private By deleteNoEcoCollectionze = By.xpath("//a[@title='Remove Eco Collection No']");
    private By deleteErinRecommendation = By.xpath("//a[@title='Remove Erin Recommends Yes']");
    private By deleteYesPerformanceFabrics = By.xpath("//a[@title='Remove Performance Fabric Yes']");
    private By clearAll = By.xpath("//a[@class='action clear filter-clear']");


    public void navigateToWomanBrasAndTanksPage() {
        driver.navigate().to(womanBrasAndTanksPageUrl);
    }

    public void clickOnStyle() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(style)).click();
    }

    public void clickOnSize() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(size)).click();
    }
    public void clickOnClimate() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(climate)).click();
    }
    public void clickOnColor() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(color)).click();
    }
    public void clickOnEcoCollection() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(ecoCollection)).click();
    }
    public void clickOnErinRecommends() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(erinRecommends)).click();
    }
    public void clickOnMaterial() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(material)).click();
    }
    public void clickOnNewOption() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(newOptiion)).click();
    }
    public void clickOnPattern() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(pattern)).click();
    }
    public void clickOnPerformanceFabrics() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(performanceFabric)).click();
    }
    public void clickOnPrice() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(price)).click();
    }
    public void clickOnSale() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(sale)).click();
    }
    public void selectTankStyle() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(tankStyle)).click();
        Thread.sleep(1500);
    }
    public void selectLSize() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(lSize)).click();
        Thread.sleep(1500);
    }
    public void selectIndoor() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(indoor)).click();
        Thread.sleep(1500);
    }
    public void selectNoEcoCollection() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(noEcoCollection)).click();
        Thread.sleep(1500);
    }
    public void selectErinRecommendation() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(erinRecommendation)).click();
        Thread.sleep(1500);
    }
    public void selectYesPerformanceFabric() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(yesPerformanceFabric)).click();
        Thread.sleep(1500);
    }
    public void clickOnDeleteTank() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(deleteTank)).click();
        Thread.sleep(1500);
    }
    public void clickOnDeleteSizeL() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(deleteSizeL)).click();
        Thread.sleep(1500);
    }
    public void clickOnDeleteClimate() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(deleteClimate)).click();
        Thread.sleep(1500);
    }
    public void clickOnDeleteNoEcoCollection() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(deleteNoEcoCollectionze)).click();
        Thread.sleep(1500);
    }
    public void clickOnDeleteErinRecommendation() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(deleteErinRecommendation)).click();
        Thread.sleep(1500);
    }
    public void clickOnDeleteYesPerformanceFabrics() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(deleteYesPerformanceFabrics)).click();
        Thread.sleep(1500);
    }
    public void clickOnClearAll() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(clearAll)).click();
        Thread.sleep(1500);
    }
}
