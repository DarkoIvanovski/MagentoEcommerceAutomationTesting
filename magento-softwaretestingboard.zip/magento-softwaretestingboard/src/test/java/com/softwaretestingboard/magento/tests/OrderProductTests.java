package com.softwaretestingboard.magento.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class OrderProductTests extends BaseTest {

    @Test
    public void orderProduct() throws InterruptedException {
        homePage.clickOnSignIn();
        signInPage.enterUserEmail("emily.johnson@example.com");
        signInPage.enterUserPassword("T3@c0dEr");
        signInPage.clickOnSignInButton();
        homePage.navigateToHomePage();
        mainMenuPage.clickOnWomenBottomsMenu();
        orderProductPage.clickOnMimiAllPurposeShort();
        orderProductPage.clickOnNextPicture();
        orderProductPage.clickOnPreviousPicture();
        orderProductPage.clickOnSecondPicture();
        orderProductPage.clickOnFirstPicture();
        orderProductPage.clickOnThirdPicture();
        orderProductPage.selectSize28();
        orderProductPage.selectGreyColor();
        orderProductPage.selectQuantity("3");
        orderProductPage.clickOnAddToCartButton();
        orderProductPage.clickOnCartIcon();
        orderProductPage.clickOnProceedToCheckoutButton();
        js.executeScript("window.scrollBy(0, 500)","");
        orderProductPage.selectShippingMethod();
        orderProductPage.clickOnNextButton();
        Thread.sleep(2000);
        orderProductPage.clickOnPlaceOrder();
        Thread.sleep(2000);
        Assert.assertEquals(orderProductPage.getMessageThankForYourOrder(),"Thank you for your purchase!");
        orderProductPage.navigateToMyOrdersPage();
    }

}
