package com.softwaretestingboard.magento.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class SignInTests extends BaseTest {

    @Test
    public void testSignInAndSignOut() throws InterruptedException {
        signInPage.navigateToSignInPage();
        signInPage.enterUserEmail("emily.johnson@example.com");
        signInPage.enterUserPassword("T3@c0dEr");
        signInPage.clickOnSignInButton();
        signInPage.signOut();
    }

    @Test
    public void testForgotPassword() {
        signInPage.navigateToSignInPage();
        signInPage.clickOnForgotYourPassword();
        signInPage.enterEmail("emily.johnson@example.com");
        signInPage.clickOnResetPasswordButton();
        Assert.assertEquals(signInPage.getResetPasswordMessage(), "If there is an account associated with emily.johnson@example.com you will receive an email with a link to reset your password.");
    }
}
