package com.softwaretestingboard.magento.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ShowProductPage {

    WebDriver driver;
    WebDriverWait wait;

    public ShowProductPage (WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    private String menJacketUrl = "https://magento.softwaretestingboard.com/men/tops-men/jackets-men.html";
    private By listProduct = By.id("mode-list");
    private By gridMode = By.id("mode-grid");
    private By sortProductBy = By.id("sorter");
    private By ascendingAndDescending = By.xpath("//div[@class='column main']/div[2]/div[3]/a/span");
    private By productPerPage = By.xpath("//div[4]/div[2]/div/select");



    public void navigateToMenJacketPage() {
        driver.navigate().to(menJacketUrl);
    }

    public void clickOnListProduct() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(listProduct)).click();
        Thread.sleep(1500);
    }

    public void clickOnGridMode() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(gridMode)).click();
        Thread.sleep(1500);
    }

    public void sortBy (String value) throws InterruptedException {
        WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(sortProductBy));
        Select select = new Select(element);
        select.selectByValue(value);
        Thread.sleep(1500);
    }

    public void orderByAscendingDescending() {
        Actions actions = new Actions(driver);
        WebElement doubleClickBtn = wait.until(ExpectedConditions.visibilityOfElementLocated(ascendingAndDescending));
        actions.moveToElement(doubleClickBtn).doubleClick().build().perform();
    }

    public void showProductPerPage (String value) throws InterruptedException {
        WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(productPerPage));
        Select select = new Select(element);
        select.selectByValue(value);
        Thread.sleep(1500);
    }
}
