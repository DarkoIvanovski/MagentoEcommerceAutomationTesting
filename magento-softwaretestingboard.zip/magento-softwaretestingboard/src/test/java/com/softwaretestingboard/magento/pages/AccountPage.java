package com.softwaretestingboard.magento.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AccountPage {

    WebDriver driver;
    WebDriverWait wait;

    public AccountPage (WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    private String accountPageUrl = "https://magento.softwaretestingboard.com/customer/account/";
    private By editAccountInfo = By.xpath("//div[@class='box box-information']/div[2]/a/span");
    private By firstName = By.id("firstname");
    private By lastName = By.id("lastname");
    private By changePasswordLink = By.xpath("//div[@class='box box-information']/div[2]/a[2]");
    private By changeEmailCheckbox = By.id("change-email");
    private By email = By.id("email");
    private By currentPasswordField = By.id("current-password");
    private By newPasswordField = By.id("password");
    private By confirmNewPassword = By.id("password-confirmation");
    private By saveButton = By.xpath("//form[@id='form-validate']/div/div/button/span");
    private By editBillingAddress = By.xpath("//div[@class='box box-billing-address']/div[2]/a/span");
    private By companyField = By.id("company");
    private By telephoneNumber = By.id("telephone");
    private By streetAddressField = By.id("street_1");
    private By cityField = By.id("city");
    private By stateField = By.id("region_id");
    private By zipCodeField = By.id("zip");
    private By countryField = By.id("country");
    private By saveAddressButton = By.xpath("//*[@id='form-validate']/div/div[1]/button/span");
    private By editShippingAddress = By.xpath("//div[@class='box box-shipping-address']/div[2]/a/span");


    public void navigateToAccountPage() {
        driver.navigate().to(accountPageUrl);
    }
    public void clickOnEditAccountInfo(){
        wait.until(ExpectedConditions.visibilityOfElementLocated(editAccountInfo)).click();
    }

    public void editFirstName(String newFirstName) throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(firstName)).clear();
        Thread.sleep(1000);
        wait.until(ExpectedConditions.visibilityOfElementLocated(firstName)).sendKeys(newFirstName);
    }

    public void editLastName(String newLastName) throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(lastName)).clear();
        Thread.sleep(1000);
        wait.until(ExpectedConditions.visibilityOfElementLocated(lastName)).sendKeys(newLastName);
    }

    public void clickOnChangeEmail() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(changeEmailCheckbox)).click();
    }
    public void clickOnChangePasswordLink(){
        wait.until(ExpectedConditions.visibilityOfElementLocated(changePasswordLink)).click();
    }

    public void editEmail(String newEmail) throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(email)).clear();
        Thread.sleep(1500);
        wait.until(ExpectedConditions.visibilityOfElementLocated(email)).sendKeys(newEmail);
    }

    public void enterPassword(String currentPassword) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(currentPasswordField)).sendKeys(currentPassword);
    }


    public void enterNewPassword (String newPassword){
        wait.until(ExpectedConditions.visibilityOfElementLocated(newPasswordField)).sendKeys(newPassword);
    }

    public void enterConfirmPassword (String confirmPassword){
        wait.until(ExpectedConditions.visibilityOfElementLocated(confirmNewPassword)).sendKeys(confirmPassword);
    }

    public void clickOnSaveInfoButton() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(saveButton)).click();
    }

    public void clickOnEditBillingAddress(){
        wait.until(ExpectedConditions.visibilityOfElementLocated(editBillingAddress)).click();
        driver.navigate().back();
    }

    public void clickOnEditShippingAddress(){
        wait.until(ExpectedConditions.visibilityOfElementLocated(editShippingAddress)).click();
    }

    public void addCompany (String company) throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(companyField)).clear();
        Thread.sleep(1500);
        wait.until(ExpectedConditions.visibilityOfElementLocated(companyField)).sendKeys(company);
    }

    public void addTelephoneNumber (String number) throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(telephoneNumber)).clear();
        Thread.sleep(1500);
        wait.until(ExpectedConditions.visibilityOfElementLocated(telephoneNumber)).sendKeys(number);
    }

    public void addStreetAddress (String street) throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(streetAddressField)).clear();
        Thread.sleep(1500);
        wait.until(ExpectedConditions.visibilityOfElementLocated(streetAddressField)).sendKeys(street);
    }

    public void addCity (String city) throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(cityField)).clear();
        Thread.sleep(1500);
        wait.until(ExpectedConditions.visibilityOfElementLocated(cityField)).sendKeys(city);
    }

    public void addCountry(String country) {
        WebElement element = driver.findElement(countryField);
        Select select = new Select(element);
        select.selectByVisibleText(country);
    }

    public void addState(String state) {
        WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(stateField));
        Select select = new Select(element);
        select.selectByValue(state);
    }

    public void addZipCode(String zip) throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(zipCodeField)).clear();
        Thread.sleep(1500);
        wait.until(ExpectedConditions.visibilityOfElementLocated(zipCodeField)).sendKeys(zip);
    }

    public void clickOnSaveAddressButton (){
        wait.until(ExpectedConditions.visibilityOfElementLocated(saveAddressButton)).click();
    }

}
