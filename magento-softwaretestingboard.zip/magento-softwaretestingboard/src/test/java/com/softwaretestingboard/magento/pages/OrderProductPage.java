package com.softwaretestingboard.magento.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class OrderProductPage {

    WebDriver driver;
    WebDriverWait wait;

    public OrderProductPage (WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    private String myOrdersURL = "https://magento.softwaretestingboard.com/sales/order/history/";
    private By mimiAllPurposeShort = By.xpath("//ol[@class='products list items product-items']/li[4]/div/div/strong/a");
    private By size28 = By.id("option-label-size-143-item-171");
    private By greyColor = By.id("option-label-color-93-item-52");
    private By quantity = By.id("qty");
    private By addToCartButton = By.id("product-addtocart-button");
    private By cartIcon = By.xpath("//a[@class='action showcart']");
    private By proceedToCheckoutButton = By.id("top-cart-btn-checkout");
    private By bestWayShippingCompany = By.xpath("//input[@value='tablerate_bestway']");
    private By nextButton = By.xpath("//button[@class='button action continue primary']");
    private By placeOderButton = By.xpath("//span[text()='Place Order']");
    private By orderMessage = By.xpath("//div[@class='page-title-wrapper']/h1/span");
    private By firstPictureProduct = By.xpath("//div[@class='fotorama__nav__shaft']/div[2]/div");
    private By secondPictureProduct = By.xpath("//div[@class='fotorama__nav__shaft']/div[3]/div");
    private By thirdPictureProduct = By.xpath("//div[@class='fotorama__nav__shaft']/div[4]/div");
    private By clickOnNextPicture = By.xpath("//div[@class='fotorama__arr fotorama__arr--next']/div");
    private By clickOnPreviousPicture = By.xpath("//div[@class='fotorama__arr fotorama__arr--prev']/div");



    public void navigateToMyOrdersPage() {
        driver.navigate().to(myOrdersURL);
    }

    public void clickOnMimiAllPurposeShort() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(mimiAllPurposeShort)).click();
    }

    public void selectSize28() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(size28)).click();
        Thread.sleep(1500);
    }

    public void selectGreyColor() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(greyColor)).click();
        Thread.sleep(1500);
    }

    public void selectQuantity(String productsQuantity) throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(quantity)).clear();
        Thread.sleep(1000);
        wait.until(ExpectedConditions.visibilityOfElementLocated(quantity)).sendKeys(productsQuantity);
        Thread.sleep(1000);
    }

    public void clickOnAddToCartButton () throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(addToCartButton)).click();
        Thread.sleep(3000);
    }

    public void clickOnCartIcon() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(cartIcon)).click();
    }

    public void clickOnProceedToCheckoutButton() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(proceedToCheckoutButton)).click();
        Thread.sleep(3000);
    }

    public void selectShippingMethod() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(bestWayShippingCompany)).click();
        Thread.sleep(3000);
    }

    public void clickOnNextButton() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(nextButton)).click();
        Thread.sleep(3000);
    }

    public void clickOnPlaceOrder() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(placeOderButton)).click();
        Thread.sleep(3000);
    }

    public String getMessageThankForYourOrder() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(orderMessage)).getText();
    }

    public void clickOnFirstPicture() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(firstPictureProduct)).click();
        Thread.sleep(150);
    }

    public void clickOnSecondPicture() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(secondPictureProduct)).click();
        Thread.sleep(1500);
    }

    public void clickOnThirdPicture() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(thirdPictureProduct)).click();
        Thread.sleep(1500);
    }

    public void clickOnNextPicture() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(clickOnNextPicture)).click();
        Thread.sleep(1500);
    }

    public void clickOnPreviousPicture() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(clickOnPreviousPicture)).click();
        Thread.sleep(1500);
    }

 }
