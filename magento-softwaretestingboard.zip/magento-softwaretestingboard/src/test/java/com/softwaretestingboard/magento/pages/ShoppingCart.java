package com.softwaretestingboard.magento.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ShoppingCart {

    WebDriver driver;
    WebDriverWait wait;

    public ShoppingCart (WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    private String shoppingCartUrl = "https://magento.softwaretestingboard.com/checkout/cart/";
    private By aetherGymPant = By.xpath("//*[@id='maincontent']/div[3]/div[1]/div[3]/ol/li[2]/div/div/strong/a");
    private By size33 = By.id("option-label-size-143-item-176");
    private By brownColor = By.id("option-label-color-93-item-51");
    private By viewAndEditCard = By.xpath("//a[@class='action viewcart']");
    private By cartQuantity = By.xpath("//div[@class='field qty']/div/label/input");
    private By updateShoppingCartButton = By.xpath("//button[@title='Update Shopping Cart']");
    private By applyDiscountCode = By.id("block-discount-heading");
    private By discountCodeField = By.id("coupon_code");
    private By applyDiscountCodeButton = By.xpath("//button[@value='Apply Discount']");
    private By discountCodeMessage = By.xpath("//div[@class='messages']/div/div");
    private By addToCartProduct = By.xpath("//ol[@class='products list items product-items']/li[2]/div/div/div[3]/div[1]/form/button/span");
    private By moveToWishlistProductTwo = By.xpath("//*[@id='shopping-cart-table']/tbody[2]/tr[2]/td/div/a[1]/span");
    private By moveToWishlistMessage = By.xpath("//div[@role='alert']/div/div");
    private By editParameters = By.xpath("//a[@title='Edit item parameters']");
    private By size36 = By.id("option-label-size-143-item-178");
    private By colorBlue = By.id("option-label-color-93-item-50");
    private By updateCartButton = By.id("product-updatecart-button");
    private By proceedToCheckoutButton = By.xpath("//ul[@class='checkout methods items checkout-methods-items']/li/button/span");
    private By deleteButton = By.xpath("//div[@class='actions-toolbar']/a[2]");


    public void navigateToShoppingCart () {
        driver.navigate().to(shoppingCartUrl);
    }

    public void clickOnAetherGymPant() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(aetherGymPant)).click();
    }

    public void selectSize33() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(size33)).click();
        Thread.sleep(1500);
    }

    public void selectBrownColor() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(brownColor)).click();
        Thread.sleep(1500);
    }

    public void clickOnViewAndEditCard() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(viewAndEditCard)).click();
    }

    public void editQuantity(String quantity) throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(cartQuantity)).clear();
        Thread.sleep(500);
        wait.until(ExpectedConditions.visibilityOfElementLocated(cartQuantity)).sendKeys(quantity);
    }

    public void clickOnUpdateShoppingCartButton() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(updateShoppingCartButton)).click();
    }

    public void clickOnApplyDiscountCode() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(applyDiscountCode)).click();
    }

    public void enterDiscountCode(String discountCode) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(discountCodeField)).sendKeys(discountCode);
    }

    public void clickOnApplyDiscountCodeButton() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(applyDiscountCodeButton)).click();
    }

    public String getDiscountCodeMessage() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(discountCodeMessage)).getText();
    }

    public void addToCartProduct() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(addToCartProduct)).click();
        Thread.sleep(2000);
    }

    public void clickOnMoveToWishlistProductTwo() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(moveToWishlistProductTwo)).click();
        Thread.sleep(3000);
    }

    public String getMoveToWishlistMessage () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(moveToWishlistMessage)).getText();
    }

    public void clickOnEditParameters() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(editParameters)).click();
    }

    public void clickOnSize36() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(size36)).click();
        Thread.sleep(3000);
    }

    public void clickOnBlueColor() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(colorBlue)).click();
        Thread.sleep(3000);
    }

    public void clickOnUpdateCartButton() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(updateCartButton)).click();
    }

    public void clickOnProceedToCheckoutButton() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(proceedToCheckoutButton)).click();
    }

    public void clickOnDeleteButton () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(deleteButton)).click();
    }






}
