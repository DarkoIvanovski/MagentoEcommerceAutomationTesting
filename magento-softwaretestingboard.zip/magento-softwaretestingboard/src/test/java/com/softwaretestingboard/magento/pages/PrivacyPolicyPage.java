package com.softwaretestingboard.magento.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PrivacyPolicyPage {

    WebDriver driver;
    WebDriverWait wait;

    public PrivacyPolicyPage(WebDriver driver, WebDriverWait wait){
        this.driver = driver;
        this.wait = wait;
    }

    private String privacyPolicyPage = "https://magento.softwaretestingboard.com/privacy-policy-cookie-restriction-mode";

    private By lumaSecurity =By.xpath("//div[@id='privacy-policy-nav-content']/ul/li[1]");
    private By lumaPrivacyPolicy =By.xpath("//div[@id='privacy-policy-nav-content']/ul/li[2]");
    private By theInformationWeCollect =By.xpath("//div[@id='privacy-policy-nav-content']/ul/li[3]");
    private By howWeUseTheInformationWeCollect =By.xpath("//div[@id='privacy-policy-nav-content']/ul/li[4]");
    private By security =By.xpath("//div[@id='privacy-policy-nav-content']/ul/li[5]");
    private By othersWithWhomWeShareYourInformation =By.xpath("//div[@id='privacy-policy-nav-content']/ul/li[6]");
    private By yourChoicesRegardingUseOfTheInformationWeCollect =By.xpath("//div[@id='privacy-policy-nav-content']/ul/li[7]");
    private By yourCaliforniaPrivacyRights =By.xpath("//div[@id='privacy-policy-nav-content']/ul/li[8]");
    private By cookiesWebBeaconsAndHowWeUseThem =By.xpath("//div[@id='privacy-policy-nav-content']/ul/li[9]");
    private By listOfCookiesWeCollect =By.xpath("//div[@id='privacy-policy-nav-content']/ul/li[10]");
    private By onlineAccountRegistration =By.xpath("//div[@id='privacy-policy-nav-content']/ul/li[11]");
    private By emails =By.xpath("//div[@id='privacy-policy-nav-content']/ul/li[12]");
    private By acceptance =By.xpath("//div[@id='privacy-policy-nav-content']/ul/li[13]");
    private By questionsForLuma =By.xpath("//div[@id='privacy-policy-nav-content']/ul/li[14]");
    private By contactUs = By.xpath("//a[text()='Contact Us']");
    private By bugMessage = By.xpath("//span[text()='Whoops, our bad...']");


    public void navigateToPrivacyPolicyPage() {
        driver.navigate().to(privacyPolicyPage);
    }

    public void clickOnLumaSecurity() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(lumaSecurity)).click();
    }

    public void clickOnLumaPrivacyPolicy() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(lumaPrivacyPolicy)).click();
    }

    public void clickOnTheInformationWeCollect() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(theInformationWeCollect)).click();
    }

    public void clickOnHowWeUseTheInformationWeCollect() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(howWeUseTheInformationWeCollect)).click();
    }

    public void clickOnSecurity() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(security)).click();
    }

    public void clickOnOthersWithWhomWeShareYourInformation() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(othersWithWhomWeShareYourInformation)).click();
    }

    public void clickOnYourChoicesRegardingUseOfTheInformationWeCollect() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(yourChoicesRegardingUseOfTheInformationWeCollect)).click();
    }

    public void clickOnYourCaliforniaPrivacyRights() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(yourCaliforniaPrivacyRights)).click();
    }

    public void clickOnCookiesWebBeaconsAndHowWeUseThem() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(cookiesWebBeaconsAndHowWeUseThem)).click();
    }

    public void clickOnListOfCookiesWeCollect() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(listOfCookiesWeCollect)).click();
    }

    public void clickOnOnlineAccountRegistration() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(onlineAccountRegistration)).click();
    }

    public void clickOnEmails() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(emails)).click();
    }

    public void clickOnAcceptance() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(acceptance)).click();
    }

    public void clickOnQuestionsForLuma() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(questionsForLuma)).click();
    }

    public void clickOnContactUs() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(contactUs)).click();
    }
    public String getBugMessage() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(bugMessage)).getText();
    }

}
