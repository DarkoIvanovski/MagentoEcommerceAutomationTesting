package com.softwaretestingboard.magento.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class OrdersAndReturnPage {

    WebDriver driver;
    WebDriverWait wait;

    public OrdersAndReturnPage (WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    private String ordersAndReturnPageUrl = "https://magento.softwaretestingboard.com/sales/guest/form/";

    private By ordersId = By.id("oar-order-id");
    private By billingLastName = By.id("oar-billing-lastname");
    private By findOrderBy = By.id("quick-search-type-id");
    private By email = By.id("oar_email");
    private By continueButton = By.xpath("//button[@class='action submit primary']");

    public void navigateToOrdersAndReturnPage() {
        driver.navigate().to(ordersAndReturnPageUrl);
    }

    public void enterOrdersId(String order){
        wait.until(ExpectedConditions.visibilityOfElementLocated(ordersId)).sendKeys(order);
    }

    public void enterBillingLastName(String lastName ){
        wait.until(ExpectedConditions.visibilityOfElementLocated(billingLastName)).sendKeys(lastName);
    }

    public void selectFindOrderBy (String value){
            WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(findOrderBy));
            Select select = new Select(element);
            select.selectByValue(value);
    }

    public void enterEmail(String userEmail ){
        wait.until(ExpectedConditions.visibilityOfElementLocated(email)).sendKeys(userEmail);
    }

    public void clickOnContinueButton() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(continueButton)).click();
    }



}
