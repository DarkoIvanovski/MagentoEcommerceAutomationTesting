package com.softwaretestingboard.magento.tests;

import org.testng.annotations.Test;

public class TrainingTests extends BaseTest {

    @Test
    public void testTrainingPage() throws InterruptedException {
        trainingPage.navigateToTrainingPage();
        trainingPage.clickOnVideoDownload();
        trainingPage.clickOnMotivateYourSelf();
        trainingPage.clickOnBeforeCreatingLuma();
        trainingPage.clickOnVideos();
    }
}
