package com.softwaretestingboard.magento.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CompareProductsPage {

    WebDriver driver;
    WebDriverWait wait;

    public CompareProductsPage(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    private String comparePageUrl = "https://magento.softwaretestingboard.com/catalog/product_compare/";
    private String pageProductOne = "https://magento.softwaretestingboard.com/sylvia-capri.html";
    private String pageProductTwo = "https://magento.softwaretestingboard.com/deirdre-relaxed-fit-capri.html";

    private By comparisonList = By.xpath("//div[@class='messages']/div/div/a");
    private By addToWishListProductOne = By.xpath("//table[@id='product-comparison']/tbody/tr/td[1]/div[2]/div[2]/a");
    private By addToWishListProductTwo = By.xpath("//table[@id='product-comparison']/tbody/tr/td[2]/div[2]/div[2]/a");
    private By addToCompareButton = By.xpath("//span[text()='Add to Compare']");
    private By addToCartProductOne = By.xpath("//table[@id='product-comparison']/tbody/tr/td[1]/div[2]/div/form/button/span");
    private By addToCartProductTwo = By.xpath("//table[@id='product-comparison']/tbody/tr/td[2]/div[2]/div/form/button/span");
    private By printThisPage = By.xpath("//a[@title='Print This Page']");
    private By removeProductOne = By.xpath("//table[@id='product-comparison']/thead/tr/td[1]/a");
    private By removeProductTwo = By.xpath("//table[@id='product-comparison']/thead/tr/td[2]/a");
    private By cancelRemoveProduct = By.xpath("//button[@class='action-secondary action-dismiss']/span");
    private By okRemoveProduct = By.xpath("//button[@class='action-primary action-accept']/span");

    public void navigateToComparePage() {
        driver.navigate().to(comparePageUrl);
    }



    public void clickOnCompareProductOne() throws InterruptedException {
        driver.navigate().to(pageProductOne);
        Thread.sleep(3000);
        wait.until(ExpectedConditions.visibilityOfElementLocated(addToCompareButton)).click();
    }

    public void clickOnCompareProductTwo() throws InterruptedException {
        driver.navigate().to(pageProductTwo);
        Thread.sleep(3000);
        wait.until(ExpectedConditions.visibilityOfElementLocated(addToCompareButton)).click();
    }

    public void clickOnComparisonList() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(comparisonList)).click();
    }

    public void clickOnAddToWishListProductOne() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(addToWishListProductOne)).click();
    }

    public void clickOnAddToWishListProductTwo(){
        wait.until(ExpectedConditions.visibilityOfElementLocated(addToWishListProductTwo)).click();
    }

    public void clickOnAddToCartProductOne() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(addToCartProductOne)).click();
        Thread.sleep(2000);
    }

    public void clickOnAddToCartProductTwo() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(addToCartProductTwo)).click();
        Thread.sleep(2000);
    }

    public void clickOnPrintThisPage(){
        wait.until(ExpectedConditions.visibilityOfElementLocated(printThisPage)).click();
    }

    public void clickOnRemoveProductOne(){
        wait.until(ExpectedConditions.visibilityOfElementLocated(removeProductOne)).click();
    }

    public void clickOnRemoveProductTwo(){
        wait.until(ExpectedConditions.visibilityOfElementLocated(removeProductTwo)).click();
    }

    public void clickCancelOnRemoveProductFromComparisonList() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(cancelRemoveProduct)).click();
        Thread.sleep(1500);
    }

    public void clickOkOnRemoveProductFromComparisonList() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(okRemoveProduct)).click();
        Thread.sleep(1500);
    }

}
