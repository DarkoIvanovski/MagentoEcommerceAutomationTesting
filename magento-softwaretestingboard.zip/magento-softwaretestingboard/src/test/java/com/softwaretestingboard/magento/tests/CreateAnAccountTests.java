package com.softwaretestingboard.magento.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class CreateAnAccountTests extends BaseTest {

    @Test
    public void createAnAccount () {
        createAnAccountPage.navigateToSignUpPage();
        createAnAccountPage.enterFirstName("Emily");
        createAnAccountPage.enterLastName("Johnson");
        createAnAccountPage.enterEmailAddress("emily.johnson@example.com");
        createAnAccountPage.enterPassword("T3@c0dEr");
        Assert.assertEquals(createAnAccountPage.getStrengthPasswordMessage(),"Medium");
        createAnAccountPage.enterConfirmPassword("T3@c0dEr");
        createAnAccountPage.clickOnCreateAnAccountButton();
    }
}
