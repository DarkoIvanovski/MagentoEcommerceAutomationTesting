package com.softwaretestingboard.magento.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SignInPage {

    WebDriver driver;
    WebDriverWait wait;

    public SignInPage (WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    private String signInPageUrl = "https://magento.softwaretestingboard.com/customer/account/login/referer/aHR0cHM6Ly9tYWdlbnRvLnNvZnR3YXJldGVzdGluZ2JvYXJkLmNvbS8%2C/";

    private By enterEmail = By.id("email");
    private By enterPassword = By.id("pass");
    private By signInButton = By.id("send2");
    private By welcome = By.xpath("//div[@class='panel header']/ul/li[2]/span/button");
    private By signOut = By.xpath("//header[@class='page-header']/div[1]/div/ul/li[2]/div/ul/li[3]/a");
    private By forgotYourPassword = By.xpath("//a[@class='action remind']/span");
    private By emailAddress = By.id("email_address");
    private By resetPasswordButton = By.xpath("//button[@class='action submit primary']/span");
    private By resetPasswordMessage = By.xpath("//div[@class='page messages']/div[2]/div/div/div");


    public void navigateToSignInPage () {
        driver.navigate().to(signInPageUrl);
    }

    public void enterUserEmail(String email) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(enterEmail)).sendKeys(email);
    }

    public void enterUserPassword(String password) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(enterPassword)).sendKeys(password);
    }

    public void clickOnSignInButton() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(signInButton)).click();
    }

    public void signOut () throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(welcome)).click();
        Thread.sleep(500);
        wait.until(ExpectedConditions.visibilityOfElementLocated(signOut)).click();
    }

    public void clickOnForgotYourPassword() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(forgotYourPassword)).click();
    }

    public void enterEmail(String userEmail) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(emailAddress)).sendKeys(userEmail);
    }

    public void clickOnResetPasswordButton() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(resetPasswordButton)).click();
    }

    public String getResetPasswordMessage() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(resetPasswordMessage)).getText();
    }


}
