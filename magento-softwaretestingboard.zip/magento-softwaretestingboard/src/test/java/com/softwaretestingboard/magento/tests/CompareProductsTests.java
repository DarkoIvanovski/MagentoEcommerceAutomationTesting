package com.softwaretestingboard.magento.tests;

import org.testng.annotations.Test;

public class CompareProductsTests extends BaseTest {

    @Test
    public void addProductsToComparisonList() throws InterruptedException {
        signInPage.navigateToSignInPage();
        homePage.clickOnSignIn();
        signInPage.enterUserEmail("emily.johnson@example.com");
        signInPage.enterUserPassword("T3@c0dEr");
        signInPage.clickOnSignInButton();
        womanPage.navigateToWomanPage();
        js.executeScript("window.scrollBy(0, 500)","");
        womanPage.clickOnPants();
        Thread.sleep(3000);
        compareProductsPage.clickOnCompareProductOne();
        compareProductsPage.clickOnCompareProductTwo();
        compareProductsPage.clickOnComparisonList();
        compareProductsPage.navigateToComparePage();
    }

    @Test
    public void addProductsFromComparisonListToWishList() throws InterruptedException {
        signInPage.navigateToSignInPage();
        homePage.clickOnSignIn();
        signInPage.enterUserEmail("emily.johnson@example.com");
        signInPage.enterUserPassword("T3@c0dEr");
        signInPage.clickOnSignInButton();
        womanPage.navigateToWomanPage();
        js.executeScript("window.scrollBy(0, 500)","");
        womanPage.clickOnPants();
        Thread.sleep(3000);
        js.executeScript("window.scrollBy(0, 500)","");
        compareProductsPage.clickOnCompareProductOne();
        js.executeScript("window.scrollBy(0, 500)","");
        compareProductsPage.clickOnCompareProductTwo();
        compareProductsPage.clickOnComparisonList();
        compareProductsPage.navigateToComparePage();
        js.executeScript("window.scrollBy(0, 500)","");
        compareProductsPage.clickOnAddToWishListProductOne();
        compareProductsPage.navigateToComparePage();
        js.executeScript("window.scrollBy(0, 500)","");
        compareProductsPage.clickOnAddToWishListProductTwo();
    }

    @Test
    public void addProductsFromComparisonListToCart() throws InterruptedException {
        signInPage.navigateToSignInPage();
        homePage.clickOnSignIn();
        signInPage.enterUserEmail("emily.johnson@example.com");
        signInPage.enterUserPassword("T3@c0dEr");
        signInPage.clickOnSignInButton();
        womanPage.navigateToWomanPage();
        js.executeScript("window.scrollBy(0, 500)","");
        womanPage.clickOnPants();
        Thread.sleep(3000);
        js.executeScript("window.scrollBy(0, 500)","");
        compareProductsPage.clickOnCompareProductOne();
        js.executeScript("window.scrollBy(0, 500)","");
        compareProductsPage.clickOnCompareProductTwo();
        compareProductsPage.clickOnComparisonList();
        compareProductsPage.navigateToComparePage();
        js.executeScript("window.scrollBy(0, 500)","");
        compareProductsPage.clickOnAddToCartProductOne();
        compareProductsPage.navigateToComparePage();
        js.executeScript("window.scrollBy(0, 500)","");
        compareProductsPage.clickOnAddToCartProductTwo();
        compareProductsPage.navigateToComparePage();
    }

    @Test
    public void clickOnPrintTisPage() throws InterruptedException {
        signInPage.navigateToSignInPage();
        homePage.clickOnSignIn();
        signInPage.enterUserEmail("emily.johnson@example.com");
        signInPage.enterUserPassword("T3@c0dEr");
        signInPage.clickOnSignInButton();
        womanPage.navigateToWomanPage();
        js.executeScript("window.scrollBy(0, 500)","");
        womanPage.clickOnPants();
        Thread.sleep(3000);
        js.executeScript("window.scrollBy(0, 500)","");
        compareProductsPage.clickOnCompareProductOne();
        js.executeScript("window.scrollBy(0, 500)","");
        compareProductsPage.clickOnCompareProductTwo();
        compareProductsPage.clickOnComparisonList();
        compareProductsPage.navigateToComparePage();
        js.executeScript("window.scrollBy(0, 500)","");
        compareProductsPage.clickOnPrintThisPage();
    }

    @Test
    public void clickCancelOnRemoveProductsFromComparisonList() throws InterruptedException {
        signInPage.navigateToSignInPage();
        homePage.clickOnSignIn();
        signInPage.enterUserEmail("emily.johnson@example.com");
        signInPage.enterUserPassword("T3@c0dEr");
        signInPage.clickOnSignInButton();
        womanPage.navigateToWomanPage();
        js.executeScript("window.scrollBy(0, 500)","");
        womanPage.clickOnPants();
        Thread.sleep(3000);
        js.executeScript("window.scrollBy(0, 500)","");
        compareProductsPage.clickOnCompareProductOne();
        js.executeScript("window.scrollBy(0, 500)","");
        compareProductsPage.clickOnCompareProductTwo();
        compareProductsPage.clickOnComparisonList();
        compareProductsPage.navigateToComparePage();
        js.executeScript("window.scrollBy(0, 500)","");
        compareProductsPage.clickOnRemoveProductOne();
        compareProductsPage.clickCancelOnRemoveProductFromComparisonList();
        compareProductsPage.clickOnRemoveProductTwo();
        compareProductsPage.clickCancelOnRemoveProductFromComparisonList();
    }

    @Test
    public void removeProductsFromComparisonList() throws InterruptedException {
        signInPage.navigateToSignInPage();
        homePage.clickOnSignIn();
        signInPage.enterUserEmail("emily.johnson@example.com");
        signInPage.enterUserPassword("T3@c0dEr");
        signInPage.clickOnSignInButton();
        womanPage.navigateToWomanPage();
        js.executeScript("window.scrollBy(0, 500)","");
        womanPage.clickOnPants();
        Thread.sleep(3000);
        js.executeScript("window.scrollBy(0, 500)","");
        compareProductsPage.clickOnCompareProductOne();
        js.executeScript("window.scrollBy(0, 500)","");
        compareProductsPage.clickOnCompareProductTwo();
        compareProductsPage.clickOnComparisonList();
        compareProductsPage.navigateToComparePage();
        js.executeScript("window.scrollBy(0, 500)","");
        compareProductsPage.clickOnRemoveProductOne();
        compareProductsPage.clickOkOnRemoveProductFromComparisonList();
        compareProductsPage.clickOnRemoveProductOne();
        compareProductsPage.clickOkOnRemoveProductFromComparisonList();
    }
}
