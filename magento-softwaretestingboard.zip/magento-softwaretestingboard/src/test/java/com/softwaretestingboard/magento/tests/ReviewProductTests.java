package com.softwaretestingboard.magento.tests;

import org.testng.annotations.Test;

public class ReviewProductTests extends BaseTest {

    @Test
    public void testReviewProduct() throws InterruptedException {
        signInPage.navigateToSignInPage();
        signInPage.enterUserEmail("emily.johnson@example.com");
        signInPage.enterUserPassword("T3@c0dEr");
        signInPage.clickOnSignInButton();
        reviewProductPage.navigateToFusionBackpackPage();
        reviewProductPage.clickOnReviewTab();
        js.executeScript("window.scrollBy(0, 500)","");
        reviewProductPage.clickOnOneStarReview();
        reviewProductPage.enterSummaryMessage("One Star");
        reviewProductPage.enterReviewMessage("One Star");
        reviewProductPage.clickOnSubmitReviewButton();
        reviewProductPage.navigateToMyProductReviewPage();
        reviewProductPage.clickOnSeeDetails();
    }

}
