package com.softwaretestingboard.magento.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class AddProductToWishlistTests extends BaseTest {

    @Test
    public void addProductToMyWishlist() {
        homePage.clickOnSignIn();
        signInPage.enterUserEmail("emily.johnson@example.com");
        signInPage.enterUserPassword("T3@c0dEr");
        signInPage.clickOnSignInButton();
        menPage.navigateToMenPage();
        menPage.clickOnShorts();
        addProductToWishlistPage.clickOnArcadioGymShorts();
        addProductToWishlistPage.clickOnAddToWishlistButton();
        addProductToWishlistPage.navigateToWishListPage();
    }


    @Test
    public void removeProductFromWishlist() {
        homePage.clickOnSignIn();
        signInPage.enterUserEmail("emily.johnson@example.com");
        signInPage.enterUserPassword("T3@c0dEr");
        signInPage.clickOnSignInButton();
        menPage.navigateToMenPage();
        menPage.clickOnShorts();
        addProductToWishlistPage.clickOnArcadioGymShorts();
        addProductToWishlistPage.clickOnAddToWishlistButton();
        addProductToWishlistPage.navigateToWishListPage();
        addProductToWishlistPage.clickOnRemoveFromWishlist();
        Assert.assertEquals(addProductToWishlistPage.getMessageFromRemoveProductFromWishlist(),"You have no items in your wish list.");
    }
}
