package com.softwaretestingboard.magento.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.concurrent.TimeUnit;

public class MainMenuPage {

    WebDriver driver;
    WebDriverWait wait;

    public MainMenuPage (WebDriver driver, WebDriverWait wait){
        this.driver = driver;
        this.wait = wait;
    }


    private By whatsNew = By.id("ui-id-3");
    private By woman = By.id("ui-id-4");
    private By womenTops = By.id("ui-id-9");
    private By womenTopsJacket = By.xpath("//li//li[@class='level2 nav-2-1-1 category-item first ui-menu-item']/a/span");
    private By womenTopsHoodiesAndSweatShirt = By.id("ui-id-12");
    private By womenTopsTees = By.id("ui-id-13");
    private By womenTopsBrasAndTanks = By.id("ui-id-14");
    private By womenBottoms = By.id("ui-id-10");
    private By womenBottomsPants = By.id("ui-id-15");
    private By womenBottomsShorts = By.id("ui-id-16");
    private By men = By.id("ui-id-5");
    private By menTops = By.id("ui-id-17");
    private By menBottoms = By.id("ui-id-18");
    private By menTopsJacket = By.id("ui-id-19");
    private By menTopsHoodiesAndSweatshirt = By.id("ui-id-20");
    private By menTopsTees = By.id("ui-id-21");
    private By menTopsTanks = By.id("ui-id-22");
    private By menBottomsPants = By.id("ui-id-23");
    private By menBottomsShorts = By.id("ui-id-24");
    private By gear = By.id("ui-id-6");
    private By gearBags = By.id("ui-id-25");
    private By gearFitnessEquipment = By.id("ui-id-26");
    private By gearWatches = By.id("ui-id-27");
    private By training = By.id("ui-id-7");
    private By trainingVideoDownload = By.id("ui-id-28");
    private By sale = By.id("ui-id-8");


    public void clickOnWhatsNew() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(whatsNew)).click();
    }

    public void clickOnWomanMenu() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(woman)).click();
    }

    public void clickOnWomenTopsMenu() {
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement womenMenu = driver.findElement(woman);
        Actions actions = new Actions(driver);
        actions.moveToElement(womenMenu).perform();

        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement womenTopsMenu = driver.findElement(womenTops);
        actions.moveToElement(womenTopsMenu).click().perform();
    }

    public void clickOnWomenTopsJacketsMenu() throws InterruptedException {
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement womenMenu = driver.findElement(woman);
        Actions actions = new Actions(driver);
        actions.moveToElement(womenMenu).perform();

        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        WebElement womenTopsMenu = driver.findElement(womenTops);
        actions.moveToElement(womenTopsMenu).click().perform();

        Thread.sleep(3000);
        wait.until(ExpectedConditions.visibilityOfElementLocated(womenTopsJacket)).click();
    }

    public void clickOnWomenTopsHoodiesAndSweatshirtMenu() throws InterruptedException {
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement womenMenu = driver.findElement(woman);
        Actions actions = new Actions(driver);
        actions.moveToElement(womenMenu).perform();

        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement womenTopsMenu = driver.findElement(womenTops);
        actions.moveToElement(womenTopsMenu).click().perform();

        Thread.sleep(3000);
        wait.until(ExpectedConditions.visibilityOfElementLocated(womenTopsHoodiesAndSweatShirt)).click();
    }

    public void clickOnWomenTopsTeesMenu() throws InterruptedException {
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement womenMenu = driver.findElement(woman);
        Actions actions = new Actions(driver);
        actions.moveToElement(womenMenu).perform();

        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement womenTopsMenu = driver.findElement(womenTops);
        actions.moveToElement(womenTopsMenu).click().perform();

        Thread.sleep(3000);
        wait.until(ExpectedConditions.visibilityOfElementLocated(womenTopsTees)).click();
    }

    public void clickOnWomenTopsBrasAndTanksMenu() throws InterruptedException {
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement womenMenu = driver.findElement(woman);
        Actions actions = new Actions(driver);
        actions.moveToElement(womenMenu).perform();

        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement womenTopsMenu = driver.findElement(womenTops);
        actions.moveToElement(womenTopsMenu).click().perform();

        Thread.sleep(3000);
        wait.until(ExpectedConditions.visibilityOfElementLocated(womenTopsBrasAndTanks)).click();
    }

    public void clickOnWomenBottomsMenu() {
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement womenMenu = driver.findElement(woman);
        Actions actions = new Actions(driver);
        actions.moveToElement(womenMenu).perform();

        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement womenBottomsMenu = driver.findElement(womenBottoms);
        actions.moveToElement(womenBottomsMenu).click().perform();
    }

    public void clickOnWomenBottomsPantsMenu() throws InterruptedException {
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement womenMenu = driver.findElement(woman);
        Actions actions = new Actions(driver);
        actions.moveToElement(womenMenu).perform();

        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement womenBottomsMenu = driver.findElement(womenBottoms);
        actions.moveToElement(womenBottomsMenu).click().perform();

        Thread.sleep(3000);
        wait.until(ExpectedConditions.visibilityOfElementLocated(womenBottomsPants)).click();
    }

    public void clickOnWomenBottomsShortsMenu() throws InterruptedException {
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement mainMenu2 = driver.findElement(woman);
        Actions actions = new Actions(driver);
        actions.moveToElement(mainMenu2).perform();

        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement womenBottomsMenu = driver.findElement(womenBottoms);
        actions.moveToElement(womenBottomsMenu).click().perform();

        Thread.sleep(3000);
        wait.until(ExpectedConditions.visibilityOfElementLocated(womenBottomsShorts)).click();
    }

    public void clickOnMenMenu() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(men)).click();
    }

    public void clickOnMenTopsMenu() {
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement menMenu = driver.findElement(men);
        Actions actions = new Actions(driver);
        actions.moveToElement(menMenu).perform();

        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement menTopsMenu = driver.findElement(menTops);
        actions.moveToElement(menTopsMenu).click().perform();
    }

    public void clickOnMenTopsJacketMenu() throws InterruptedException {
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement menMenu = driver.findElement(men);
        Actions actions = new Actions(driver);
        actions.moveToElement(menMenu).perform();

        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement menTopsMenu = driver.findElement(menTops);
        actions.moveToElement(menTopsMenu).click().perform();

        Thread.sleep(3000);
        wait.until(ExpectedConditions.visibilityOfElementLocated(menTopsJacket)).click();
    }

    public void clickOnMenTopsHoodiesAndSweatShirtMenu() throws InterruptedException {
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement menMenu = driver.findElement(men);
        Actions actions = new Actions(driver);
        actions.moveToElement(menMenu).perform();

        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement menTopsMenu = driver.findElement(menTops);
        actions.moveToElement(menTopsMenu).click().perform();

        Thread.sleep(3000);
        wait.until(ExpectedConditions.visibilityOfElementLocated(menTopsHoodiesAndSweatshirt)).click();
    }

    public void clickOnMenTopsTeesMenu() throws InterruptedException {
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement menMenu = driver.findElement(men);
        Actions actions = new Actions(driver);
        actions.moveToElement(menMenu).perform();

        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement menTopsMenu = driver.findElement(menTops);
        actions.moveToElement(menTopsMenu).click().perform();

        Thread.sleep(3000);
        wait.until(ExpectedConditions.visibilityOfElementLocated(menTopsTees)).click();
    }

    public void clickOnMenTopsTanksMenu() throws InterruptedException {
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement menMenu = driver.findElement(men);
        Actions actions = new Actions(driver);
        actions.moveToElement(menMenu).perform();

        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement menTopsMenu = driver.findElement(menTops);
        actions.moveToElement(menTopsMenu).click().perform();

        Thread.sleep(3000);
        wait.until(ExpectedConditions.visibilityOfElementLocated(menTopsTanks)).click();
    }

    public void clickOnMenBottomsMenu() {
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement menMenu = driver.findElement(men);
        Actions actions = new Actions(driver);
        actions.moveToElement(menMenu).perform();

        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement menBottomsMenu = driver.findElement(menBottoms);
        actions.moveToElement(menBottomsMenu).click().perform();
    }

    public void clickOnMenBottomsPantsMenu() throws InterruptedException {
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement menMenu = driver.findElement(men);
        Actions actions = new Actions(driver);
        actions.moveToElement(menMenu).perform();

        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement menBottomsMenu = driver.findElement(menBottoms);
        actions.moveToElement(menBottomsMenu).click().perform();

        Thread.sleep(3000);
        wait.until(ExpectedConditions.visibilityOfElementLocated(menBottomsPants)).click();
    }

    public void clickOnMenBottomsShortsMenu() throws InterruptedException {
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement menMenu = driver.findElement(men);
        Actions actions = new Actions(driver);
        actions.moveToElement(menMenu).perform();

        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement menBottomsMenu = driver.findElement(menBottoms);
        actions.moveToElement(menBottomsMenu).click().perform();

        Thread.sleep(3000);
        wait.until(ExpectedConditions.visibilityOfElementLocated(menBottomsShorts)).click();
    }

    public void clickOnGearMenu() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(gear)).click();
    }

    public void clickOnGearBagsMenu() {
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement gearMenu = driver.findElement(gear);
        Actions actions = new Actions(driver);
        actions.moveToElement(gearMenu).perform();

        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement gearBagsMenu = driver.findElement(gearBags);
        actions.moveToElement(gearBagsMenu).click().perform();
    }

    public void clickOnGearFitnessEquipmentMenu() {
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement gearMenu = driver.findElement(gear);
        Actions actions = new Actions(driver);
        actions.moveToElement(gearMenu).perform();

        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement gearFitnessEquipmentMenu = driver.findElement(gearFitnessEquipment);
        actions.moveToElement(gearFitnessEquipmentMenu).click().perform();
    }

    public void clickOnGearWatchesMenu() {
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement gearMenu = driver.findElement(gear);
        Actions actions = new Actions(driver);
        actions.moveToElement(gearMenu).perform();

        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement gearWatchesMenu = driver.findElement(gearWatches);
        actions.moveToElement(gearWatchesMenu).click().perform();
    }

    public void clickOnTrainingMenu() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(training)).click();
    }

    public void clickOnTrainingVideoDownloadMenu() {
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement trainingMenu = driver.findElement(training);
        Actions actions = new Actions(driver);
        actions.moveToElement(trainingMenu).perform();

        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement videoDownloadMenu = driver.findElement(trainingVideoDownload);
        actions.moveToElement(videoDownloadMenu).click().perform();
    }

    public void clickOnSale() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(sale)).click();
    }
}
