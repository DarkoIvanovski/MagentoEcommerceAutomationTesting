package com.softwaretestingboard.magento.tests;

import org.testng.annotations.Test;

public class GearTests extends BaseTest {

    @Test
    public void shopByCategory() throws InterruptedException {
        gearPage.navigateToGearPage();
        gearPage.clickOnBags();
        gearPage.clickOnFitnessEquipment();
        gearPage.clickOnWatches();
    }

    @Test
    public void shopByHeaderImages() throws InterruptedException {
        gearPage.navigateToGearPage();
        gearPage.clickOnShopYogaKit();
        gearPage.clickOnShopFitness();
        gearPage.clickOnHereToYou();
        gearPage.clickOnShopBags();
        gearPage.clickOnShopEquipment();
        gearPage.clickOnShopWatches();
    }

    @Test
    public void hotSellersProducts() throws InterruptedException {
        gearPage.navigateToGearPage();
        gearPage.clickOnFusionBackpack();
        gearPage.clickOnPushItMessengerBag();
        gearPage.clickOnAffirmWaterBottle();
        gearPage.clickOnSpriteYogaCompanionKit();
    }
}
