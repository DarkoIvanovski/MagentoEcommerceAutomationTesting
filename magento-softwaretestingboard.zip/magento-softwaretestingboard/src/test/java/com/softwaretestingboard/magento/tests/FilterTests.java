package com.softwaretestingboard.magento.tests;

import org.testng.annotations.Test;

public class FilterTests extends BaseTest {

    @Test
    public void testMainSoppingOptions() {
        filterPage.navigateToWomanBrasAndTanksPage();
        filterPage.clickOnStyle();
        filterPage.clickOnSize();
        filterPage.clickOnClimate();
        filterPage.clickOnColor();
        filterPage.clickOnEcoCollection();
        filterPage.clickOnErinRecommends();
        filterPage.clickOnMaterial();
        filterPage.clickOnNewOption();
        filterPage.clickOnPattern();
        filterPage.clickOnPerformanceFabrics();
        filterPage.clickOnPrice();
        filterPage.clickOnSale();
    }

    @Test
    public void testSelectMultipleSoppingOptions() throws InterruptedException {
        filterPage.navigateToWomanBrasAndTanksPage();
        filterPage.clickOnStyle();
        filterPage.selectTankStyle();
        filterPage.clickOnSize();
        filterPage.selectLSize();
        filterPage.clickOnClimate();
        filterPage.selectIndoor();
        filterPage.clickOnEcoCollection();
        filterPage.selectNoEcoCollection();
        filterPage.clickOnErinRecommends();
        filterPage.selectErinRecommendation();
        filterPage.clickOnPerformanceFabrics();
        filterPage.selectYesPerformanceFabric();
    }

    @Test
    public void deleteOptionPerOption() throws InterruptedException {
        filterPage.navigateToWomanBrasAndTanksPage();
        filterPage.clickOnStyle();
        filterPage.selectTankStyle();
        filterPage.clickOnSize();
        filterPage.selectLSize();
        filterPage.clickOnClimate();
        filterPage.selectIndoor();
        filterPage.clickOnEcoCollection();
        filterPage.selectNoEcoCollection();
        filterPage.clickOnErinRecommends();
        filterPage.selectErinRecommendation();
        filterPage.clickOnPerformanceFabrics();
        filterPage.selectYesPerformanceFabric();
        filterPage.clickOnDeleteTank();
        filterPage.clickOnDeleteSizeL();
        filterPage.clickOnDeleteClimate();
        filterPage.clickOnDeleteNoEcoCollection();
        filterPage.clickOnDeleteErinRecommendation();
        filterPage.clickOnDeleteYesPerformanceFabrics();
    }

    @Test
    public void deleteAllOptionsWithOneClick() throws InterruptedException {
        filterPage.navigateToWomanBrasAndTanksPage();
        filterPage.clickOnStyle();
        filterPage.selectTankStyle();
        filterPage.clickOnSize();
        filterPage.selectLSize();
        filterPage.clickOnClimate();
        filterPage.selectIndoor();
        filterPage.clickOnEcoCollection();
        filterPage.selectNoEcoCollection();
        filterPage.clickOnErinRecommends();
        filterPage.selectErinRecommendation();
        filterPage.clickOnPerformanceFabrics();
        filterPage.selectYesPerformanceFabric();
        filterPage.clickOnClearAll();
    }





}
