package com.softwaretestingboard.magento.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ReviewProductPage {

    WebDriver driver;
    WebDriverWait wait;

    public ReviewProductPage(WebDriver driver, WebDriverWait wait){
        this.driver = driver;
        this.wait = wait;
    }

    private String fusionBackpackPageUrl = "https://magento.softwaretestingboard.com/fusion-backpack.html";
    private String myProductReviewPageUrl = "https://magento.softwaretestingboard.com/review/customer/";

    private By reviewTab = By.xpath("//a[@id='tab-label-reviews-title']");
    private By summaryField = By.xpath("//input[@id='summary_field']");
    private By reviewField = By.xpath("//textarea[@id='review_field']");
    private By submitReviewButton = By.xpath("//button[@class='action submit primary']/span");
    private By seeDetails = By.xpath("//span[text()='See Details']");



    public void navigateToFusionBackpackPage() {
        driver.navigate().to(fusionBackpackPageUrl);
    }

    public void clickOnReviewTab() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(reviewTab)).click();
        Thread.sleep(2000);
    }

    public void clickOnOneStarReview() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//label[@id='Rating_1_label']"))).click();
    }

    public void enterSummaryMessage(String summary) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(summaryField)).sendKeys(summary);
    }

    public void enterReviewMessage(String review) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(reviewField)).sendKeys(review);
    }

    public void clickOnSubmitReviewButton() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(submitReviewButton)).click();
        Thread.sleep(2000);
    }

    public void navigateToMyProductReviewPage(){
        driver.navigate().to(myProductReviewPageUrl);
    }

    public void clickOnSeeDetails() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(seeDetails)).click();
    }

}
