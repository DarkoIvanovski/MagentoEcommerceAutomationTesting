package com.softwaretestingboard.magento.tests;

import org.testng.annotations.Test;

public class AccountTests extends BaseTest {

    @Test
    public void editContactInfo() throws InterruptedException {
        signInPage.navigateToSignInPage();
        signInPage.enterUserEmail("emily.johnson@example.com");
        signInPage.enterUserPassword("T3@c0dEr");
        signInPage.clickOnSignInButton();
        accountPage.navigateToAccountPage();
        accountPage.clickOnEditAccountInfo();
        accountPage.editFirstName("Michael");
        accountPage.editLastName("Smith");
        //accountPage.clickOnSaveInfoButton();
    }

    @Test
    public void editEmail() throws InterruptedException {
        signInPage.navigateToSignInPage();
        signInPage.enterUserEmail("emily.johnson@example.com");
        signInPage.enterUserPassword("T3@c0dEr");
        signInPage.clickOnSignInButton();
        accountPage.navigateToAccountPage();
        accountPage.clickOnEditAccountInfo();
        accountPage.clickOnChangeEmail();
        accountPage.editEmail("michael.smith@example.com");
        accountPage.enterPassword("T3@c0dEr");
        //accountPage.clickOnSaveInfoButton();
    }

    @Test
    public void editPassword() {
        signInPage.navigateToSignInPage();
        signInPage.enterUserEmail("emily.johnson@example.com");
        signInPage.enterUserPassword("T3@c0dEr");
        signInPage.clickOnSignInButton();
        accountPage.navigateToAccountPage();
        accountPage.clickOnChangePasswordLink();
        accountPage.enterPassword("T3@c0dEr");
        accountPage.enterNewPassword("P@ssw0rd!1");
        accountPage.enterConfirmPassword("P@ssw0rd!1");
        //accountPage.clickOnSaveInfoButton();
    }

    @Test
    public void editAddress() throws InterruptedException {
        signInPage.navigateToSignInPage();
        signInPage.enterUserEmail("emily.johnson@example.com");
        signInPage.enterUserPassword("T3@c0dEr");
        signInPage.clickOnSignInButton();
        accountPage.navigateToAccountPage();
        accountPage.clickOnEditBillingAddress();
        accountPage.clickOnEditShippingAddress();
        accountPage.addCompany("Tech Innovations Inc.");
        accountPage.addTelephoneNumber("+1-555-123-4567");
        accountPage.addStreetAddress("123 Maple Street");
        accountPage.addCity("Springfield");
        accountPage.addCountry("United States");
        accountPage.addState("23");
        accountPage.addZipCode("62704");
        accountPage.clickOnSaveAddressButton();
    }
}
